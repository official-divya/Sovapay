import React from 'react';
import { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import Stats from './components/Stats';
import Footer from './components/Footer';
import AepsServices from './components/AepsServices';
import DmtServices from './components/DmtServices';
import UtilityServices from './components/UtilityServices';
import MicroAtmServices from './components/MicroAtmServices';
import FintechSoftware from './components/FintechSoftware';
import PayoutSolutions from './components/PayoutSolutions';
import ContactUs from './components/ContactUs';
import KycVerification from './components/KycVerification';
import AboutUs from './components/AboutUs';
import PrivacyPolicy from './components/PrivacyPolicy';
import TermsConditions from './components/TermsConditions';
import DeveloperSection from './components/DeveloperSection';

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'aeps':
        return <AepsServices />;
      case 'dmt':
        return <DmtServices />;
      case 'utility':
        return <UtilityServices />;
      case 'micro-atm':
        return <MicroAtmServices />;
      case 'fintech-software':
        return <FintechSoftware />;
      case 'payout-solutions':
        return <PayoutSolutions />;
      case 'contact':
        return <ContactUs />;
      case 'kyc-verification':
        return <KycVerification />;
      case 'about':
        return <AboutUs />;
      case 'privacy':
        return <PrivacyPolicy />;
      case 'terms':
        return <TermsConditions />;
      default:
        return (
          <>
            <Hero setCurrentPage={setCurrentPage} />
            <Services />
            <DeveloperSection />
            <Stats setCurrentPage={setCurrentPage} />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen">
      <Header currentPage={currentPage} setCurrentPage={setCurrentPage} />
      {renderPage()}
      <Footer setCurrentPage={setCurrentPage} />
    </div>
  );
}

export default App;