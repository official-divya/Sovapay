import React from 'react';
import { 
  Users, 
  Target, 
  Award, 
  CheckCircle,
  ArrowRight,
  TrendingUp,
  Building2,
  Smartphone,
  CreditCard,
  Globe,
  Zap,
  DollarSign,
  Star,
  Shield,
  BarChart3,
  Fingerprint,
  Lock,
  Eye,
  Database,
  Settings,
  Search,
  Clock,
  Heart,
  Lightbulb,
  Handshake,
  Rocket,
  MapPin,
  Phone,
  Mail
} from 'lucide-react';

const AboutUs = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Enhanced Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-64 h-64 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-br from-indigo-200/30 to-blue-200/30 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
          <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-gradient-to-br from-purple-200/20 to-pink-200/20 rounded-full blur-2xl animate-pulse" style={{animationDelay: '4s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-6">
                <div className="inline-flex items-center space-x-2 bg-blue-100 rounded-full px-4 py-2 border border-blue-200">
                  <Users className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-700">Transforming Financial Technology</span>
                </div>

                <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  About <span className="text-blue-600">SovaPay</span>
                </h1>
                
                <p className="text-lg text-gray-600 leading-relaxed">
                  SovaPay Technologies is one of the new-generation companies in the competitive 
                  environment of the Indian fintech scene, which focuses on the Fintech industry. 
                  We started in April 2023 and our mission is to transform the way companies in 
                  India manage their finances and make payments.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105 shadow-lg">
                  <span>Join Our Team</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
                
                <button className="border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-4 rounded-full font-semibold transition-all duration-300">
                  Learn More
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="flex items-center space-x-8 pt-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">Since 2023</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">98,000+ Retailers</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">Expert Team</span>
                </div>
              </div>
            </div>

            {/* Enhanced Right Content - Premium Team Animation */}
            <div className="relative">
              <div className="relative w-full h-[500px] perspective-1000">
                {/* Enhanced Background Gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 to-purple-100/50 rounded-3xl overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-200/20 via-transparent to-purple-200/20"></div>
                </div>

                {/* Main 3D Scene Container */}
                <div className="absolute inset-0 transform-gpu preserve-3d" style={{transform: 'rotateX(10deg) rotateY(-10deg) translateZ(0)'}}>
                  
                  {/* Enhanced Team Members */}
                  <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-15deg) rotateY(20deg)'}}>
                      {/* Team Shadow */}
                      <div className="absolute top-12 left-12 w-48 h-32 bg-black/15 rounded-2xl blur-lg transform skew-x-6 skew-y-6"></div>
                      
                      {/* Team Container */}
                      <div className="w-48 h-32 bg-gradient-to-b from-white to-gray-100 rounded-2xl shadow-2xl border border-gray-200 relative overflow-hidden">
                        {/* Container Highlight */}
                        <div className="absolute top-1 left-2 w-12 h-8 bg-white/60 rounded blur-sm"></div>
                        
                        {/* Browser Header */}
                        <div className="flex items-center space-x-2 p-3 border-b border-gray-200">
                          <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                          <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                          <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                          <div className="ml-2 text-xs text-gray-500">SovaPay Team</div>
                        </div>
                        
                        {/* Team Members */}
                        <div className="p-4 flex justify-center space-x-4">
                          {/* Team Member 1 */}
                          <div className="relative animate-float-slow">
                            <div className="w-12 h-16 bg-gradient-to-b from-blue-500 to-blue-700 rounded-t-full relative">
                              {/* Head */}
                              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-yellow-200 rounded-full shadow-lg border border-yellow-100"></div>
                              
                              {/* Device */}
                              <div className="absolute top-2 right-0 w-2 h-3 bg-gray-800 rounded-sm"></div>
                              
                              {/* Badge */}
                              <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2">
                                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                              </div>
                            </div>
                          </div>

                          {/* Team Member 2 - Center */}
                          <div className="relative animate-float-medium" style={{animationDelay: '1s'}}>
                            <div className="w-14 h-18 bg-gradient-to-b from-purple-500 to-purple-700 rounded-t-full relative">
                              {/* Head */}
                              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-5 h-5 bg-yellow-200 rounded-full shadow-lg border border-yellow-100"></div>
                              
                              {/* Laptop */}
                              <div className="absolute top-3 left-1/2 transform -translate-x-1/2 w-3 h-2 bg-gray-800 rounded-sm"></div>
                              
                              {/* Leader Badge */}
                              <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2">
                                <div className="w-3 h-3 bg-yellow-500 rounded-full flex items-center justify-center">
                                  <Star className="w-1.5 h-1.5 text-white" />
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Team Member 3 */}
                          <div className="relative animate-float-fast" style={{animationDelay: '2s'}}>
                            <div className="w-12 h-16 bg-gradient-to-b from-green-500 to-green-700 rounded-t-full relative">
                              {/* Head */}
                              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-yellow-200 rounded-full shadow-lg border border-yellow-100"></div>
                              
                              {/* Glasses */}
                              <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-3 h-1 border border-gray-800 rounded-full"></div>
                              
                              {/* Tablet */}
                              <div className="absolute top-2 left-0 w-2 h-3 bg-gray-800 rounded-sm"></div>
                              
                              {/* Badge */}
                              <div className="absolute bottom-1 left-1/2 transform -translate-x-1/2">
                                <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Floating Tech Icons */}
                  <div className="absolute top-20 right-20 animate-float-slow">
                    <div className="relative transform rotate-12">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl shadow-xl border border-blue-300 flex items-center justify-center">
                        <Phone className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  </div>

                  <div className="absolute bottom-24 left-8 animate-float-medium" style={{animationDelay: '1s'}}>
                    <div className="relative transform -rotate-12">
                      <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-700 rounded-xl shadow-xl border border-purple-300 flex items-center justify-center">
                        <Mail className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  </div>

                  <div className="absolute top-32 left-24 animate-float-fast" style={{animationDelay: '2s'}}>
                    <div className="relative transform rotate-6">
                      <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-700 rounded-xl shadow-xl border border-green-300 flex items-center justify-center">
                        <Globe className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Golden Coins */}
                  <div className="absolute top-40 right-32 animate-coin-bounce">
                    <div className="relative">
                      <div className="w-8 h-8 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-xs">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-8 h-2 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  <div className="absolute bottom-32 left-32 animate-coin-bounce" style={{animationDelay: '0.5s'}}>
                    <div className="relative">
                      <div className="w-6 h-6 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-xs">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-6 h-1.5 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  {/* Network Connection Lines */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-80 h-80 border border-dashed border-blue-300/30 rounded-full animate-spin opacity-40" style={{animationDuration: '30s'}}></div>
                    <div className="absolute w-64 h-64 border border-dashed border-purple-300/25 rounded-full animate-spin opacity-35" style={{animationDuration: '25s', animationDirection: 'reverse'}}></div>
                  </div>

                  {/* Floating Particles */}
                  <div className="absolute top-16 left-40 w-2 h-2 bg-blue-400 rounded-full animate-ping"></div>
                  <div className="absolute bottom-20 left-24 w-1.5 h-1.5 bg-purple-400 rounded-full animate-ping" style={{animationDelay: '1s'}}></div>
                  <div className="absolute top-40 right-32 w-1 h-1 bg-green-400 rounded-full animate-ping" style={{animationDelay: '2s'}}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Mission Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <h2 className="text-4xl font-bold text-gray-900">
                Our <span className="text-blue-600">Mission</span>
              </h2>
              
              <p className="text-lg text-gray-600 leading-relaxed">
                The goal at SovaPay Technologies is to help businesses manage their finances more 
                effectively and efficiently with the help of modern technologies that are safe and 
                effective. Our mission is to provide everyone with the tools of modern finance and 
                promote development and stability in the communities.
              </p>

              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                    <Target className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-gray-700 font-medium">Empowering businesses with modern financial tools</span>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center">
                    <Shield className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-gray-700 font-medium">Ensuring safe and secure financial transactions</span>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center">
                    <Heart className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-gray-700 font-medium">Promoting community development and stability</span>
                </div>
              </div>
            </div>

            {/* Right Content - Mission Animation */}
            <div className="relative">
              <div className="relative w-full h-80 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-3xl p-8 overflow-hidden">
                {/* Mission Visualization */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full shadow-2xl flex items-center justify-center relative">
                    <Target className="w-10 h-10 text-white" />
                    
                    {/* Orbiting Mission Elements */}
                    <div className="absolute inset-0 animate-spin" style={{animationDuration: '12s'}}>
                      <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center shadow-lg">
                        <Shield className="w-4 h-4 text-white" />
                      </div>
                      <div className="absolute -right-8 top-1/2 transform -translate-y-1/2 w-8 h-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center shadow-lg">
                        <Lightbulb className="w-4 h-4 text-white" />
                      </div>
                      <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
                        <Heart className="w-4 h-4 text-white" />
                      </div>
                      <div className="absolute -left-8 top-1/2 transform -translate-y-1/2 w-8 h-8 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center shadow-lg">
                        <TrendingUp className="w-4 h-4 text-white" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Floating Elements */}
                <div className="absolute top-8 left-8 w-6 h-6 bg-blue-400 rounded-full animate-bounce flex items-center justify-center">
                  <Rocket className="w-3 h-3 text-white" />
                </div>
                <div className="absolute bottom-8 right-8 w-6 h-6 bg-green-400 rounded-full animate-pulse flex items-center justify-center">
                  <Star className="w-3 h-3 text-white" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced What We Offer Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              What We <span className="text-blue-600">Offer</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive financial technology solutions designed to transform your business operations
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Service 1 */}
            <div className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <CreditCard className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Comprehensive Payment Solutions</h3>
              <p className="text-gray-600 leading-relaxed">
                Our payment systems enable strong and fast payment for companies of all sizes to accept payments. 
                Whether in the local grocery stores or in the online market places we facilitate smooth transactions 
                and efficient invoicing systems that improve business processes.
              </p>
            </div>

            {/* Service 2 */}
            <div className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <BarChart3 className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Financial Management Tools</h3>
              <p className="text-gray-600 leading-relaxed">
                We know how it feels to be in a fix when it comes to handling money. Our user-friendly software 
                offers meaningful reports to business owners who can then make better decisions and manage their finances.
              </p>
            </div>

            {/* Service 3 */}
            <div className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Eye className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Business Insights and Analytics</h3>
              <p className="text-gray-600 leading-relaxed">
                Business decisions that are based on facts are the most effective for the growth of any organization. 
                The analytics dashboard is a convenient tool that provides information on sales and inventory, which 
                can help entrepreneurs enhance their work and satisfy clients.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Our Impact Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-600/80 via-purple-600/80 to-indigo-600/80"></div>
          <div className="absolute top-20 left-20 w-32 h-32 bg-white/10 rounded-full blur-2xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-40 h-40 bg-white/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Our Impact
            </h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Making a difference in the financial technology landscape across India
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Impact 1 */}
            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Promoting Financial Inclusion</h3>
              <p className="text-gray-600 leading-relaxed">
                We are focused on providing financial services to people regardless of their location. Our solutions 
                enable communities to embrace contemporary payment solutions that support economic activity.
              </p>
            </div>

            {/* Impact 2 */}
            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Smartphone className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Encouraging a Cashless Economy</h3>
              <p className="text-gray-600 leading-relaxed">
                India has been predominantly a cash-driven economy for a long time. This is especially the case with 
                our digital payment solutions that help eliminate the use of physical money in financial transactions.
              </p>
            </div>

            {/* Impact 3 */}
            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Building2 className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Supporting Job Creation</h3>
              <p className="text-gray-600 leading-relaxed">
                In this way, we help businesses grow and, consequently, create new jobs. The solutions we provide assist 
                firms to grow and to be profitable, creating jobs in the process.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Looking Ahead Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Looking <span className="text-blue-600">Ahead</span>
            </h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Globe className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Expanding Our Reach</h3>
                    <p className="text-gray-600 leading-relaxed">
                      We are constantly striving to expand our service to other parts of the country so that every 
                      business can leverage our solutions.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Shield className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Strengthening Security</h3>
                    <p className="text-gray-600 leading-relaxed">
                      Security is a very sensitive aspect that should be upheld to the highest level in the organization. 
                      To ensure that our users place their trust in us, we are committed to improving our security systems.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Handshake className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Collaborating with Banks</h3>
                    <p className="text-gray-600 leading-relaxed">
                      We aim to create a seamless financial ecosystem by collaborating with traditional banks. This 
                      partnership will enable us to offer comprehensive services that cater to the diverse needs of businesses.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Content - Future Vision Animation */}
            <div className="relative">
              <div className="relative w-full h-96 bg-gradient-to-br from-purple-100 to-pink-100 rounded-3xl p-8 overflow-hidden">
                {/* Future Vision Visualization */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-24 h-24 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full shadow-2xl flex items-center justify-center relative">
                    <Rocket className="w-12 h-12 text-white" />
                    
                    {/* Orbiting Future Elements */}
                    <div className="absolute inset-0 animate-spin" style={{animationDuration: '15s'}}>
                      <div className="absolute -top-10 left-1/2 transform -translate-x-1/2 w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center shadow-lg">
                        <Globe className="w-5 h-5 text-white" />
                      </div>
                      <div className="absolute -right-10 top-1/2 transform -translate-y-1/2 w-10 h-10 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center shadow-lg">
                        <Shield className="w-5 h-5 text-white" />
                      </div>
                      <div className="absolute -bottom-10 left-1/2 transform -translate-x-1/2 w-10 h-10 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
                        <Handshake className="w-5 h-5 text-white" />
                      </div>
                      <div className="absolute -left-10 top-1/2 transform -translate-y-1/2 w-10 h-10 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center shadow-lg">
                        <Lightbulb className="w-5 h-5 text-white" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Floating Future Elements */}
                <div className="absolute top-8 left-8 w-8 h-8 bg-blue-400 rounded-full animate-bounce flex items-center justify-center">
                  <Star className="w-4 h-4 text-white" />
                </div>
                <div className="absolute bottom-8 right-8 w-8 h-8 bg-green-400 rounded-full animate-pulse flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-white" />
                </div>
                <div className="absolute top-16 right-16 w-6 h-6 bg-purple-400 rounded-full animate-ping"></div>
              </div>
            </div>
          </div>

          {/* Closing Statement */}
          <div className="text-center mt-16 max-w-4xl mx-auto">
            <p className="text-lg text-gray-600 leading-relaxed">
              SovaPay Technologies is more than a fintech startup; we are a catalyst for economic empowerment. 
              As India's SMEs embrace digital transformation, we stand by their side, supporting their growth and success.
            </p>
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gray-900 via-blue-900 to-indigo-900 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-gray-900/90 via-blue-900/90 to-indigo-900/90"></div>
          <div className="absolute top-20 left-20 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 text-center relative z-10">
          <div className="max-w-4xl mx-auto space-y-8">
            <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
              Ready to Transform Your Business with SovaPay?
            </h2>
            <p className="text-xl text-blue-100 leading-relaxed">
              Join thousands of businesses who trust SovaPay for their financial technology needs. 
              Let's build the future of finance together.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg">
                Get Started Today
              </button>
              <button className="border-2 border-white/30 hover:border-white/50 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 hover:bg-white/10 backdrop-blur-sm">
                Contact Our Team
              </button>
            </div>
          </div>
        </div>
      </section>

      <style jsx>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .preserve-3d {
          transform-style: preserve-3d;
        }
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          33% { transform: translateY(-8px) translateX(4px) rotateZ(2deg); }
          66% { transform: translateY(4px) translateX(-2px) rotateZ(-1deg); }
        }
        @keyframes float-medium {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          50% { transform: translateY(-12px) translateX(6px) rotateZ(3deg); }
        }
        @keyframes float-fast {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          25% { transform: translateY(-6px) translateX(3px) rotateZ(1deg); }
          75% { transform: translateY(6px) translateX(-3px) rotateZ(-2deg); }
        }
        @keyframes coin-bounce {
          0%, 100% { transform: translateY(0px) rotateY(0deg); }
          25% { transform: translateY(-8px) rotateY(90deg); }
          50% { transform: translateY(-4px) rotateY(180deg); }
          75% { transform: translateY(-8px) rotateY(270deg); }
        }
        .animate-float-slow {
          animation: float-slow 6s ease-in-out infinite;
        }
        .animate-float-medium {
          animation: float-medium 4s ease-in-out infinite;
        }
        .animate-float-fast {
          animation: float-fast 3s ease-in-out infinite;
        }
        .animate-coin-bounce {
          animation: coin-bounce 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default AboutUs;