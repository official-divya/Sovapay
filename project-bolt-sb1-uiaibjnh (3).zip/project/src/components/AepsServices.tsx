import React from 'react';
import { 
  Headphones, 
  TrendingUp, 
  Banknote, 
  Shield, 
  Users, 
  Smartphone,
  CheckCircle,
  ArrowRight,
  CreditCard,
  Fingerprint
} from 'lucide-react';

const AepsServices = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-6">
                <h1 className="text-5xl lg:text-6xl font-bold text-gray-900">
                  <span className="text-blue-600">AePS</span> Aadhaar Banking
                </h1>
                
                <p className="text-lg text-gray-600 leading-relaxed">
                  At SovaPay Technologies, we fully support the government's drive towards 
                  financial literacy in India through the Aadhaar banking services. With SovaPay, 
                  customers can avail of Cash Withdrawal, Balance Enquiries, Mini-Statements, 
                  Aadhaar Pay, and Cash Deposits. The customers and rural retailers are the 
                  beneficiaries of our Aadhaar banking services. Retailers are paid based on the 
                  number of sales made, meaning they have an extra source of income and 
                  improve the availability of funds in their regions.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105">
                  <span>Get Started</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
                
                <button className="border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-4 rounded-full font-semibold transition-all duration-300">
                  Learn More
                </button>
              </div>
            </div>

            {/* Right Content - AePS Illustration */}
            <div className="relative">
              <div className="relative w-full h-96 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-3xl p-8 overflow-hidden">
                {/* Background Elements */}
                <div className="absolute top-8 right-8 w-32 h-20 bg-green-400 rounded-2xl transform rotate-12 opacity-80">
                  <div className="p-4 text-white">
                    <div className="text-2xl font-bold">₹</div>
                    <div className="text-sm">Cash</div>
                  </div>
                </div>

                {/* Mobile Device */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-32 h-56 bg-gradient-to-b from-gray-800 to-gray-900 rounded-2xl shadow-2xl border-4 border-gray-700 relative overflow-hidden">
                    {/* Screen */}
                    <div className="p-3 pt-6">
                      <div className="h-44 bg-gradient-to-b from-blue-500 to-blue-700 rounded-xl relative overflow-hidden">
                        {/* AePS Logo */}
                        <div className="absolute top-4 left-1/2 transform -translate-x-1/2">
                          <div className="bg-white rounded-lg p-2 shadow-lg">
                            <span className="text-blue-600 font-bold text-xs">AePS</span>
                          </div>
                        </div>
                        
                        {/* Aadhaar Symbol */}
                        <div className="absolute top-16 left-1/2 transform -translate-x-1/2">
                          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-lg">
                            <Fingerprint className="w-8 h-8 text-blue-600" />
                          </div>
                        </div>
                        
                        {/* AADHAAR ATM Text */}
                        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-center">
                          <div className="text-white font-bold text-xs">AADHAAR</div>
                          <div className="text-white font-bold text-xs">ATM</div>
                        </div>
                        
                        {/* Fingerprint Animation */}
                        <div className="absolute bottom-8 right-4">
                          <div className="w-8 h-8 bg-yellow-400 rounded-full animate-pulse flex items-center justify-center">
                            <div className="w-4 h-4 bg-yellow-600 rounded-full"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Credit Card */}
                <div className="absolute bottom-8 left-8 transform rotate-12">
                  <div className="w-24 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg shadow-xl p-2">
                    <div className="text-white text-xs font-bold">BANK</div>
                    <div className="text-white text-xs mt-1">**** 1234</div>
                    <div className="absolute top-2 right-2 w-4 h-4 bg-yellow-400 rounded-full"></div>
                  </div>
                </div>

                {/* Coins Stack */}
                <div className="absolute bottom-12 right-12">
                  <div className="relative">
                    <div className="w-12 h-3 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full"></div>
                    <div className="w-12 h-3 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full -mt-1"></div>
                    <div className="w-12 h-3 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full -mt-1"></div>
                    <div className="w-12 h-3 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full -mt-1"></div>
                  </div>
                </div>

                {/* Floating Elements */}
                <div className="absolute top-12 left-12 w-4 h-4 bg-blue-500 rounded-full animate-bounce"></div>
                <div className="absolute top-20 right-20 w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                <div className="absolute bottom-20 left-16 w-2 h-2 bg-purple-500 rounded-full animate-ping"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Benefits of SovaPay's AePS Services
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Benefit 1 */}
            <div className="bg-white rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-shadow">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
                <Headphones className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Dedicated Customer Support</h3>
              <p className="text-gray-600 leading-relaxed">
                Get the advantage of round-the-clock customer support and be assured that all your questions and concerns are addressed instantly.
              </p>
            </div>

            {/* Benefit 2 */}
            <div className="bg-white rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-shadow">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
                <TrendingUp className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">High Commission</h3>
              <p className="text-gray-600 leading-relaxed">
                Receive competitive commissions for each transaction, which will help you increase your revenues.
              </p>
            </div>

            {/* Benefit 3 */}
            <div className="bg-white rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-shadow">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
                <Banknote className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Easy Cash Withdrawal</h3>
              <p className="text-gray-600 leading-relaxed">
                Enjoy seamless and hassle-free cash withdrawals, making it convenient for you to access funds whenever needed.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <h2 className="text-4xl font-bold text-gray-900">
                Why Choose <span className="text-blue-600">SovaPay</span> for AePS Services?
              </h2>

              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 mb-2">Comprehensive Service Range</h3>
                    <p className="text-gray-600">We offer all the basic banking needs ranging from cash deposits to balance enquiries among other services.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 mb-2">User-Friendly Technology</h3>
                    <p className="text-gray-600">The platform is easy to navigate to make it easily accessible for all customers including those in rural areas.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 mb-2">Enhanced Security</h3>
                    <p className="text-gray-600">Security measures are put in place to ensure that your transactions and personal details are secure.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Content - Security Illustration */}
            <div className="relative">
              <div className="relative w-full h-80 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-3xl p-8 overflow-hidden">
                {/* Mobile Device with Security */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-24 h-40 bg-gradient-to-b from-gray-800 to-gray-900 rounded-xl shadow-2xl border-2 border-gray-700 relative overflow-hidden">
                    <div className="p-2 pt-3">
                      <div className="h-32 bg-gradient-to-b from-blue-500 to-blue-700 rounded-lg relative overflow-hidden">
                        {/* AePS Logo */}
                        <div className="absolute top-2 left-1/2 transform -translate-x-1/2">
                          <div className="bg-white rounded px-2 py-1">
                            <span className="text-blue-600 font-bold text-xs">AePS</span>
                          </div>
                        </div>
                        
                        {/* Security Shield */}
                        <div className="absolute top-8 left-1/2 transform -translate-x-1/2">
                          <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
                            <Shield className="w-6 h-6 text-white" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Security Person */}
                <div className="absolute right-8 bottom-8">
                  <div className="w-16 h-20 bg-gradient-to-b from-blue-600 to-blue-800 rounded-t-full relative">
                    {/* Head */}
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-yellow-200 rounded-full"></div>
                    {/* Shield */}
                    <div className="absolute top-2 left-1/2 transform -translate-x-1/2">
                      <div className="w-6 h-6 bg-green-500 rounded flex items-center justify-center">
                        <Shield className="w-4 h-4 text-white" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Floating Security Elements */}
                <div className="absolute top-8 left-8 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center animate-bounce">
                  <CheckCircle className="w-4 h-4 text-white" />
                </div>
                
                <div className="absolute bottom-16 left-12 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center animate-pulse">
                  <Shield className="w-3 h-3 text-white" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="container mx-auto px-6 text-center">
          <div className="max-w-3xl mx-auto space-y-8">
            <h2 className="text-4xl font-bold text-white">
              Choose SovaPay Technologies now and take your business to new heights with our outstanding AEPS solutions.
            </h2>
            <p className="text-xl text-blue-100">
              Get attractive high commissions, professional customer support, and fast cash withdrawals for your financial operations.
            </p>
            <button className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105">
              Contact Us
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AepsServices;