import React, { useState } from 'react';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Send, 
  CheckCircle,
  Clock,
  Users,
  Shield,
  MessageSquare,
  Headphones,
  Globe,
  Star,
  ArrowRight,
  Building2
} from 'lucide-react';

const ContactUs = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Enhanced Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-64 h-64 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-br from-indigo-200/30 to-blue-200/30 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
          <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-gradient-to-br from-purple-200/20 to-pink-200/20 rounded-full blur-2xl animate-pulse" style={{animationDelay: '4s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-2 bg-blue-100 rounded-full px-4 py-2 border border-blue-200 mb-6">
              <MessageSquare className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-700">24/7 Customer Support</span>
            </div>

            <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              How Can We <span className="text-blue-600">Assist You?</span>
            </h1>
            
            <p className="text-xl text-gray-600 leading-relaxed max-w-4xl mx-auto mb-8">
              Have questions about our fintech solutions or need expert support? Our dedicated team is here to help you succeed. 
              Your satisfaction is our top priority, and we're committed to providing you with exceptional service and innovative solutions 
              tailored to your business needs.
            </p>

            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center items-center gap-8 pt-4">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                <span className="text-sm text-gray-600">24/7 Support</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                <span className="text-sm text-gray-600">Expert Team</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                <span className="text-sm text-gray-600">Quick Response</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                <span className="text-sm text-gray-600">Secure Communication</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Contact Form Section */}
      <section className="py-20 bg-white relative overflow-hidden">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            {/* Left Side - Contact Form */}
            <div className="relative">
              {/* Enhanced 3D Contact Card */}
              <div className="relative w-full perspective-1000">
                <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 p-8 lg:p-12 relative overflow-hidden transform-gpu preserve-3d" style={{transform: 'rotateX(5deg) rotateY(-5deg)'}}>
                  {/* Card Glow Effect */}
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 via-purple-500/5 to-indigo-500/5 rounded-3xl"></div>
                  
                  {/* Browser-like Header */}
                  <div className="flex items-center space-x-2 mb-8 pb-4 border-b border-gray-100">
                    <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                    <div className="ml-4 text-sm text-gray-500">Contact Form</div>
                  </div>

                  <div className="relative z-10">
                    <h2 className="text-3xl font-bold text-gray-900 mb-2">
                      <span className="text-blue-600">CONTACT</span> US
                    </h2>
                    <div className="w-12 h-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mb-8"></div>

                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="group">
                          <label className="block text-sm font-semibold text-gray-700 mb-2">Full Name *</label>
                          <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-all duration-300 group-hover:border-gray-300"
                            placeholder="Enter your full name"
                            required
                          />
                        </div>
                        
                        <div className="group">
                          <label className="block text-sm font-semibold text-gray-700 mb-2">Email Address *</label>
                          <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-all duration-300 group-hover:border-gray-300"
                            placeholder="Enter your email"
                            required
                          />
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="group">
                          <label className="block text-sm font-semibold text-gray-700 mb-2">Phone Number *</label>
                          <input
                            type="tel"
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-all duration-300 group-hover:border-gray-300"
                            placeholder="+91 9654607040"
                            required
                          />
                        </div>
                        
                        <div className="group">
                          <label className="block text-sm font-semibold text-gray-700 mb-2">Subject *</label>
                          <select
                            name="subject"
                            value={formData.subject}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-all duration-300 group-hover:border-gray-300"
                            required
                          >
                            <option value="">Select a subject</option>
                            <option value="aeps">AePS Services</option>
                            <option value="dmt">Domestic Money Transfer</option>
                            <option value="utility">Utility Payment Solutions</option>
                            <option value="micro-atm">Micro ATM</option>
                            <option value="fintech">Fintech Software</option>
                            <option value="payout">Payout Solutions</option>
                            <option value="partnership">Partnership Inquiry</option>
                            <option value="support">Technical Support</option>
                            <option value="other">Other</option>
                          </select>
                        </div>
                      </div>

                      <div className="group">
                        <label className="block text-sm font-semibold text-gray-700 mb-2">Message *</label>
                        <textarea
                          name="message"
                          value={formData.message}
                          onChange={handleInputChange}
                          rows={5}
                          className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-all duration-300 group-hover:border-gray-300 resize-none"
                          placeholder="Tell us about your requirements or questions..."
                          required
                        ></textarea>
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-xl font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105 shadow-lg"
                      >
                        <Send className="w-5 h-5" />
                        <span>Send Message</span>
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Side - Contact Information & Animation */}
            <div className="space-y-8">
              {/* Contact Information Cards */}
              <div className="space-y-6">
                <h3 className="text-3xl font-bold text-gray-900 mb-8">Get In Touch</h3>
                
                {/* Phone Card */}
                <div className="group bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:transform hover:scale-105 border border-blue-100">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <Phone className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-gray-900 mb-1">Phone Support</h4>
                      <p className="text-blue-600 font-semibold text-lg">+91 9654607040</p>
                      <p className="text-sm text-gray-600">Available 24/7 for urgent support</p>
                    </div>
                  </div>
                </div>

                {/* Email Card */}
                <div className="group bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:transform hover:scale-105 border border-purple-100">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <Mail className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-gray-900 mb-1">Email Support</h4>
                      <p className="text-purple-600 font-semibold">letask@sovapay.net</p>
                      <p className="text-sm text-gray-600">We'll respond within 2 hours</p>
                    </div>
                  </div>
                </div>

                {/* Address Card */}
                <div className="group bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:transform hover:scale-105 border border-green-100">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <MapPin className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-gray-900 mb-1">Office Address</h4>
                      <p className="text-green-600 font-semibold">44 IIND FLOOR REGAL BUILDING,</p>
                      <p className="text-green-600 font-semibold">CONNAUGHT PLACE, NEW DELHI</p>
                      <p className="text-sm text-gray-600">Visit us during business hours</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Enhanced Support Animation */}
              <div className="relative w-full h-80 bg-gradient-to-br from-gray-50 to-blue-50 rounded-3xl p-8 overflow-hidden">
                {/* Background Elements */}
                <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-200/20 via-transparent to-purple-200/20"></div>
                
                {/* Support Representative */}
                <div className="absolute right-8 top-1/2 transform -translate-y-1/2">
                  <div className="w-20 h-24 bg-gradient-to-b from-blue-500 to-blue-700 rounded-t-full relative animate-float-slow">
                    {/* Head */}
                    <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-yellow-200 rounded-full shadow-lg border-2 border-yellow-100"></div>
                    
                    {/* Headset */}
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <div className="w-10 h-6 border-2 border-gray-800 rounded-full"></div>
                      <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-1 h-3 bg-gray-800 rounded"></div>
                    </div>
                    
                    {/* Support Badge */}
                    <div className="absolute top-2 left-1/2 transform -translate-x-1/2">
                      <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                        <Headphones className="w-3 h-3 text-white" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Customer */}
                <div className="absolute left-8 top-1/2 transform -translate-y-1/2">
                  <div className="w-16 h-20 bg-gradient-to-b from-green-400 to-green-600 rounded-t-full relative animate-float-medium">
                    {/* Head */}
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-yellow-200 rounded-full shadow-lg border-2 border-yellow-100"></div>
                    
                    {/* Mobile */}
                    <div className="absolute top-2 right-0 w-4 h-6 bg-gray-800 rounded"></div>
                  </div>
                </div>

                {/* Communication Lines */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-32 h-1 bg-gradient-to-r from-green-400 via-blue-500 to-purple-500 rounded-full relative">
                    <div className="absolute top-1/2 transform -translate-y-1/2 w-3 h-3 bg-yellow-400 rounded-full animate-ping"></div>
                  </div>
                </div>

                {/* Floating Support Icons */}
                <div className="absolute top-8 left-16 w-8 h-8 bg-blue-500 rounded-full animate-bounce flex items-center justify-center">
                  <MessageSquare className="w-4 h-4 text-white" />
                </div>
                
                <div className="absolute bottom-8 right-16 w-6 h-6 bg-green-500 rounded-full animate-pulse flex items-center justify-center">
                  <CheckCircle className="w-3 h-3 text-white" />
                </div>

                <div className="absolute top-16 right-24 w-4 h-4 bg-purple-500 rounded-full animate-ping"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Why Choose Us Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-600/80 via-purple-600/80 to-indigo-600/80"></div>
          <div className="absolute top-20 left-20 w-32 h-32 bg-white/10 rounded-full blur-2xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-40 h-40 bg-white/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Why Choose SovaPay Support?
            </h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Experience world-class customer service with our dedicated support team
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {/* Support Feature Cards */}
            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">24/7 Availability</h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Round-the-clock support to ensure your business never stops
              </p>
            </div>

            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Expert Team</h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Certified fintech professionals ready to solve your challenges
              </p>
            </div>

            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Secure Support</h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Bank-level security for all your support communications
              </p>
            </div>

            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                <Star className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Premium Service</h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                Personalized solutions tailored to your business needs
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gray-900 via-blue-900 to-indigo-900 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-gray-900/90 via-blue-900/90 to-indigo-900/90"></div>
          <div className="absolute top-20 left-20 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 text-center relative z-10">
          <div className="max-w-4xl mx-auto space-y-8">
            <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
              Ready to Transform Your Business?
            </h2>
            <p className="text-xl text-blue-100 leading-relaxed">
              Join thousands of businesses who trust SovaPay for their fintech solutions. 
              Get started today and experience the difference our expert team can make.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center space-x-2">
                <span>Schedule a Demo</span>
                <ArrowRight className="w-5 h-5" />
              </button>
              <button className="border-2 border-white/30 hover:border-white/50 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 hover:bg-white/10 backdrop-blur-sm">
                Download Brochure
              </button>
            </div>
          </div>
        </div>
      </section>

      <style jsx>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .preserve-3d {
          transform-style: preserve-3d;
        }
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          33% { transform: translateY(-8px) translateX(4px) rotateZ(2deg); }
          66% { transform: translateY(4px) translateX(-2px) rotateZ(-1deg); }
        }
        @keyframes float-medium {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          50% { transform: translateY(-12px) translateX(6px) rotateZ(3deg); }
        }
        .animate-float-slow {
          animation: float-slow 6s ease-in-out infinite;
        }
        .animate-float-medium {
          animation: float-medium 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default ContactUs;