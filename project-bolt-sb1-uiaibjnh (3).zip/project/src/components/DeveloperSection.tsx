import React from 'react';
import { Code, Terminal, Book, Zap, Shield, Globe } from 'lucide-react';

const DeveloperSection = () => {
  return (
    <section className="py-20 bg-gray-900 relative overflow-hidden">
      {/* Animated Background Lines */}
      <div className="absolute inset-0 overflow-hidden">
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1200 600" fill="none">
          {/* Flowing curved lines */}
          <path 
            d="M-100 300 Q200 100 400 300 T800 300 Q1000 200 1300 300" 
            stroke="url(#gradient1)" 
            strokeWidth="2" 
            fill="none"
            className="animate-pulse"
          />
          <path 
            d="M-100 400 Q300 200 500 400 T900 400 Q1100 300 1400 400" 
            stroke="url(#gradient2)" 
            strokeWidth="2" 
            fill="none"
            className="animate-pulse"
            style={{animationDelay: '1s'}}
          />
          <path 
            d="M-100 200 Q250 50 450 200 T850 200 Q1050 100 1350 200" 
            stroke="url(#gradient3)" 
            strokeWidth="2" 
            fill="none"
            className="animate-pulse"
            style={{animationDelay: '2s'}}
          />
          
          {/* Gradient definitions */}
          <defs>
            <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3B82F6" stopOpacity="0" />
              <stop offset="50%" stopColor="#3B82F6" stopOpacity="0.6" />
              <stop offset="100%" stopColor="#8B5CF6" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="gradient2" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#8B5CF6" stopOpacity="0" />
              <stop offset="50%" stopColor="#8B5CF6" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#06B6D4" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="gradient3" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#06B6D4" stopOpacity="0" />
              <stop offset="50%" stopColor="#06B6D4" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#3B82F6" stopOpacity="0" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-6">
              <div className="inline-flex items-center space-x-2 bg-blue-500/20 rounded-full px-4 py-2 border border-blue-500/30">
                <Code className="w-4 h-4 text-blue-400" />
                <span className="text-sm font-medium text-blue-300">API Integration</span>
              </div>

              <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
                Developer-Friendly
              </h2>
              
              <p className="text-lg text-gray-300 leading-relaxed">
                For the tech-savvy, we provide well-documented APIs with clear 
                documentation. Easy to build and integrate with - and we'll talk your 
                language.
              </p>
            </div>

            {/* Developer Features */}
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <Book className="w-4 h-4 text-blue-400" />
                </div>
                <span className="text-gray-300">Comprehensive API Documentation</span>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <Zap className="w-4 h-4 text-green-400" />
                </div>
                <span className="text-gray-300">Quick Integration & Setup</span>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-purple-500/20 rounded-lg flex items-center justify-center">
                  <Shield className="w-4 h-4 text-purple-400" />
                </div>
                <span className="text-gray-300">Secure & Reliable Infrastructure</span>
              </div>
            </div>

            <button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg">
              View API Docs
            </button>
          </div>

          {/* Right Content - Terminal and Floating Elements */}
          <div className="relative">
            {/* Floating Code Elements */}
            <div>
              <div className="absolute -top-4 -right-4 w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center backdrop-blur-sm border border-blue-500/30">
                <Terminal className="w-6 h-6 text-blue-400" />
              </div>
              
              <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center backdrop-blur-sm border border-purple-500/30">
                <Globe className="w-6 h-6 text-purple-400" />
              </div>
            </div>
          </div>
          </div>
      </div>
    </section>
  );
};

export default DeveloperSection;