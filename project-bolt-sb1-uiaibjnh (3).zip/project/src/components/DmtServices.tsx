import React from 'react';
import { 
  Shield, 
  Clock, 
  Building2, 
  CheckCircle,
  ArrowRight,
  Banknote,
  Users,
  Zap,
  Globe,
  CreditCard,
  Smartphone,
  TrendingUp,
  Lock,
  Timer,
  MapPin
} from 'lucide-react';

const DmtServices = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Enhanced Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-64 h-64 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-br from-indigo-200/30 to-blue-200/30 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
          <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-gradient-to-br from-purple-200/20 to-pink-200/20 rounded-full blur-2xl animate-pulse" style={{animationDelay: '4s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-6">
                <div className="inline-flex items-center space-x-2 bg-blue-100 rounded-full px-4 py-2 border border-blue-200">
                  <Zap className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-700">Instant Money Transfer</span>
                </div>

                <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  <span className="text-blue-600">DMT</span> Domestic Money Transfer
                </h1>
                
                <p className="text-lg text-gray-600 leading-relaxed">
                  Money transfer is one of the most basic and frequent requirements of people 
                  in their daily lives. At SovaPay Technologies, we empower rural and migrant 
                  communities with our convenient remittance services. When it comes to 
                  money transfers, SovaPay makes it very easy for users. Customers can visit their 
                  nearest SovaPay-associated merchant to complete transactions. Our growing 
                  list of merchants means that people do not have to go to banks, especially in 
                  rural areas.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105 shadow-lg">
                  <span>Start Transfer</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
                
                <button className="border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-4 rounded-full font-semibold transition-all duration-300">
                  Learn More
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="flex items-center space-x-8 pt-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">Instant Transfer</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">24/7 Available</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">Secure & Safe</span>
                </div>
              </div>
            </div>

            {/* Enhanced Right Content - Premium DMT Animation */}
            <div className="relative">
              <div className="relative w-full h-[500px] perspective-1000">
                {/* Enhanced Background Gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 to-purple-100/50 rounded-3xl overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-200/20 via-transparent to-purple-200/20"></div>
                </div>

                {/* Main 3D Scene Container */}
                <div className="absolute inset-0 transform-gpu preserve-3d" style={{transform: 'rotateX(10deg) rotateY(-10deg) translateZ(0)'}}>
                  
                  {/* Enhanced Bank Building */}
                  <div className="absolute right-16 top-16">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-20deg) rotateY(-30deg)'}}>
                      {/* Building Shadow */}
                      <div className="absolute top-16 left-16 w-32 h-24 bg-black/15 rounded-xl blur-xl transform skew-x-12 skew-y-6"></div>
                      
                      {/* Main Bank Building */}
                      <div className="w-32 h-24 bg-gradient-to-b from-indigo-100 to-indigo-200 rounded-xl shadow-2xl border border-indigo-300 relative overflow-hidden">
                        {/* Building Highlight */}
                        <div className="absolute top-1 left-2 w-8 h-4 bg-white/40 rounded blur-sm"></div>
                        
                        {/* Right Side */}
                        <div className="absolute top-0 -right-4 w-4 h-24 bg-gradient-to-b from-indigo-200 to-indigo-400 transform skew-y-12 shadow-lg"></div>
                        
                        {/* Top Side */}
                        <div className="absolute -top-3 left-0 w-32 h-3 bg-gradient-to-r from-indigo-50 to-indigo-200 transform skew-x-12 shadow-lg"></div>
                        
                        {/* Bank Facade */}
                        <div className="p-3">
                          {/* Bank Sign */}
                          <div className="h-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded mb-2 flex items-center justify-center">
                            <span className="text-white text-xs font-bold">BANK</span>
                          </div>
                          
                          {/* Columns */}
                          <div className="flex justify-between mb-2">
                            <div className="w-1 h-8 bg-indigo-400 rounded"></div>
                            <div className="w-1 h-8 bg-indigo-400 rounded"></div>
                            <div className="w-1 h-8 bg-indigo-400 rounded"></div>
                            <div className="w-1 h-8 bg-indigo-400 rounded"></div>
                          </div>
                          
                          {/* Bank Entrance */}
                          <div className="h-4 bg-gradient-to-b from-indigo-300 to-indigo-500 rounded flex items-center justify-center">
                            <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Floating Bank Icon */}
                      <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 animate-float-slow">
                        <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full shadow-lg flex items-center justify-center">
                          <Building2 className="w-4 h-4 text-white" />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Mobile Phones with Transfer Animation */}
                  <div className="absolute left-12 top-1/2 transform -translate-y-1/2">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-15deg) rotateY(20deg)'}}>
                      {/* Sender Phone Shadow */}
                      <div className="absolute top-8 left-8 w-20 h-36 bg-black/20 rounded-2xl blur-lg transform skew-x-6 skew-y-6"></div>
                      
                      {/* Sender Phone */}
                      <div className="w-20 h-36 bg-gradient-to-b from-slate-800 to-slate-900 rounded-2xl shadow-2xl border-2 border-slate-700 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-4 h-8 bg-white/10 rounded-lg blur-sm"></div>
                        <div className="absolute top-0 -right-2 w-2 h-36 bg-gradient-to-b from-slate-900 to-black transform skew-y-6 shadow-lg"></div>
                        
                        <div className="p-2 pt-3">
                          <div className="h-28 bg-gradient-to-br from-blue-600 via-blue-700 to-purple-800 rounded-xl relative overflow-hidden shadow-inner border border-blue-500">
                            <div className="absolute inset-0 bg-gradient-to-t from-transparent to-white/5"></div>
                            
                            {/* Transfer Interface */}
                            <div className="absolute top-2 left-2 right-2">
                              <div className="text-center mb-2">
                                <div className="text-white text-xs font-bold">SEND MONEY</div>
                              </div>
                              
                              {/* Amount Display */}
                              <div className="bg-white/20 rounded p-1 mb-2 text-center">
                                <div className="text-white text-xs">₹5,000</div>
                              </div>
                              
                              {/* Transfer Button */}
                              <div className="bg-green-500 rounded p-1 text-center animate-pulse">
                                <div className="text-white text-xs font-bold">SEND</div>
                              </div>
                              
                              {/* Status Indicators */}
                              <div className="flex justify-center space-x-1 mt-2">
                                <div className="w-1 h-1 bg-green-400 rounded-full animate-pulse"></div>
                                <div className="w-1 h-1 bg-green-400 rounded-full animate-pulse" style={{animationDelay: '0.2s'}}></div>
                                <div className="w-1 h-1 bg-green-400 rounded-full animate-pulse" style={{animationDelay: '0.4s'}}></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Receiver Phone */}
                  <div className="absolute right-32 bottom-16">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-15deg) rotateY(-20deg)'}}>
                      <div className="absolute top-8 left-8 w-20 h-36 bg-black/20 rounded-2xl blur-lg transform skew-x-6 skew-y-6"></div>
                      
                      <div className="w-20 h-36 bg-gradient-to-b from-slate-800 to-slate-900 rounded-2xl shadow-2xl border-2 border-slate-700 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-4 h-8 bg-white/10 rounded-lg blur-sm"></div>
                        <div className="absolute top-0 -right-2 w-2 h-36 bg-gradient-to-b from-slate-900 to-black transform skew-y-6 shadow-lg"></div>
                        
                        <div className="p-2 pt-3">
                          <div className="h-28 bg-gradient-to-br from-green-600 via-green-700 to-emerald-800 rounded-xl relative overflow-hidden shadow-inner border border-green-500">
                            <div className="absolute inset-0 bg-gradient-to-t from-transparent to-white/5"></div>
                            
                            {/* Receive Interface */}
                            <div className="absolute top-2 left-2 right-2">
                              <div className="text-center mb-2">
                                <div className="text-white text-xs font-bold">RECEIVED</div>
                              </div>
                              
                              {/* Amount Display */}
                              <div className="bg-white/20 rounded p-1 mb-2 text-center">
                                <div className="text-white text-xs">₹5,000</div>
                              </div>
                              
                              {/* Success Indicator */}
                              <div className="bg-green-400 rounded p-1 text-center">
                                <div className="text-white text-xs font-bold">SUCCESS</div>
                              </div>
                              
                              {/* Checkmark */}
                              <div className="flex justify-center mt-2">
                                <div className="w-4 h-4 bg-green-400 rounded-full flex items-center justify-center animate-pulse">
                                  <CheckCircle className="w-2 h-2 text-white" />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Money Transfer Animation */}
                  <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    {/* Transfer Path */}
                    <div className="relative w-48 h-2">
                      <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-green-500 rounded-full opacity-30"></div>
                      
                      {/* Animated Money Flow */}
                      <div className="absolute top-1/2 transform -translate-y-1/2 w-4 h-4 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full shadow-lg animate-money-flow">
                        <div className="absolute inset-0 bg-yellow-300 rounded-full animate-ping"></div>
                        <div className="absolute inset-1 bg-white rounded-full flex items-center justify-center">
                          <span className="text-xs font-bold text-yellow-600">₹</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Floating Currency Notes */}
                  <div className="absolute top-20 left-20 animate-float-slow">
                    <div className="relative transform rotate-12">
                      <div className="w-16 h-10 bg-gradient-to-r from-green-500 to-green-700 rounded shadow-xl border border-green-400 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-3 h-3 bg-green-300 rounded-full"></div>
                        <div className="absolute bottom-1 right-1 text-white text-xs font-bold">₹</div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                      </div>
                    </div>
                  </div>

                  <div className="absolute bottom-24 right-8 animate-float-medium" style={{animationDelay: '1s'}}>
                    <div className="relative transform -rotate-12">
                      <div className="w-16 h-10 bg-gradient-to-r from-blue-500 to-blue-700 rounded shadow-xl border border-blue-400 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-3 h-3 bg-blue-300 rounded-full"></div>
                        <div className="absolute bottom-1 right-1 text-white text-xs font-bold">₹</div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Golden Coins */}
                  <div className="absolute top-32 right-20 animate-coin-bounce">
                    <div className="relative">
                      <div className="w-8 h-8 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-xs">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-8 h-2 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  <div className="absolute bottom-32 left-32 animate-coin-bounce" style={{animationDelay: '0.5s'}}>
                    <div className="relative">
                      <div className="w-6 h-6 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-xs">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-6 h-1.5 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  {/* Network Connection Lines */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-80 h-80 border border-dashed border-blue-300/30 rounded-full animate-spin opacity-40" style={{animationDuration: '30s'}}></div>
                    <div className="absolute w-64 h-64 border border-dashed border-purple-300/25 rounded-full animate-spin opacity-35" style={{animationDuration: '25s', animationDirection: 'reverse'}}></div>
                  </div>

                  {/* Floating Particles */}
                  <div className="absolute top-16 left-40 w-2 h-2 bg-blue-400 rounded-full animate-ping"></div>
                  <div className="absolute bottom-20 left-24 w-1.5 h-1.5 bg-purple-400 rounded-full animate-ping" style={{animationDelay: '1s'}}></div>
                  <div className="absolute top-40 right-32 w-1 h-1 bg-green-400 rounded-full animate-ping" style={{animationDelay: '2s'}}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Why Choose Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-600/80 via-purple-600/80 to-indigo-600/80"></div>
          <div className="absolute top-20 left-20 w-32 h-32 bg-white/10 rounded-full blur-2xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-40 h-40 bg-white/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Why Choose SovaPay's DMT Services?
            </h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Experience the fastest, most secure, and reliable money transfer services
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Enhanced Benefit Cards */}
            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Unmatched Security and Encryption</h3>
              <p className="text-gray-600 leading-relaxed">
                We have a secure and encrypted network that guarantees the safety of your transactions in 
                every transfer. Make attractive commissions for each transaction, which will allow you to 
                increase your earnings and offer a profitable business proposal.
              </p>
            </div>

            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Clock className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">24/7 Real-Time Transactions</h3>
              <p className="text-gray-600 leading-relaxed">
                Enjoy round-the-clock customer support so that any question or concern you may have is 
                addressed immediately. Our system is capable of processing real-time transactions; therefore, 
                you can transfer money to any bank in India at any time.
              </p>
            </div>

            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Building2 className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Nationwide Bank Transfers</h3>
              <p className="text-gray-600 leading-relaxed">
                With SovaPay, you can transfer funds to any bank across India, making it convenient and efficient 
                to support your family or handle business needs.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Quick and Reliable Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Enhanced Left Animation */}
            <div className="relative">
              <div className="relative w-full h-96 bg-gradient-to-br from-green-100 to-blue-100 rounded-3xl p-8 overflow-hidden">
                {/* Background Elements */}
                <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-green-200/20 via-transparent to-blue-200/20"></div>
                
                {/* Enhanced Transfer Visualization */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  {/* Central Hub */}
                  <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full shadow-2xl flex items-center justify-center relative">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center">
                      <ArrowRight className="w-8 h-8 text-white animate-pulse" />
                    </div>
                    
                    {/* Orbiting Money Icons */}
                    <div className="absolute inset-0 animate-spin" style={{animationDuration: '8s'}}>
                      <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg">
                        <span className="text-white text-xs font-bold">₹</span>
                      </div>
                      <div className="absolute -right-8 top-1/2 transform -translate-y-1/2 w-6 h-6 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center shadow-lg">
                        <span className="text-white text-xs font-bold">₹</span>
                      </div>
                      <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center shadow-lg">
                        <span className="text-white text-xs font-bold">₹</span>
                      </div>
                      <div className="absolute -left-8 top-1/2 transform -translate-y-1/2 w-6 h-6 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
                        <span className="text-white text-xs font-bold">₹</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Enhanced People Illustrations */}
                <div className="absolute left-8 top-16">
                  <div className="relative">
                    {/* Person 1 */}
                    <div className="w-16 h-20 bg-gradient-to-b from-blue-500 to-blue-700 rounded-t-full relative animate-float-slow">
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-yellow-200 rounded-full"></div>
                      <div className="absolute top-2 left-1/2 transform -translate-x-1/2">
                        <Smartphone className="w-4 h-4 text-white" />
                      </div>
                    </div>
                    {/* Money bag */}
                    <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-gradient-to-br from-green-500 to-green-700 rounded-full flex items-center justify-center animate-bounce">
                      <Banknote className="w-4 h-4 text-white" />
                    </div>
                  </div>
                </div>

                <div className="absolute right-8 bottom-16">
                  <div className="relative">
                    {/* Person 2 */}
                    <div className="w-16 h-20 bg-gradient-to-b from-green-500 to-green-700 rounded-t-full relative animate-float-medium">
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-yellow-200 rounded-full"></div>
                      <div className="absolute top-2 left-1/2 transform -translate-x-1/2">
                        <CheckCircle className="w-4 h-4 text-white animate-pulse" />
                      </div>
                    </div>
                    {/* Success indicator */}
                    <div className="absolute -bottom-2 -left-2 w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center animate-pulse">
                      <TrendingUp className="w-4 h-4 text-white" />
                    </div>
                  </div>
                </div>

                {/* Enhanced Floating Elements */}
                <div className="absolute top-8 right-16 w-4 h-4 bg-yellow-400 rounded-full animate-bounce"></div>
                <div className="absolute bottom-8 left-16 w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                <div className="absolute top-24 left-24 w-2 h-2 bg-blue-400 rounded-full animate-ping"></div>
              </div>
            </div>

            {/* Right Content */}
            <div className="space-y-8">
              <h2 className="text-4xl font-bold text-gray-900">
                <span className="text-blue-600">Quick</span> and <span className="text-purple-600">Reliable</span> Money Transfers
              </h2>
              
              <p className="text-lg text-gray-600 leading-relaxed">
                Get fast and secure transactions with SovaPay's Domestic Money 
                Transfer services. Our system is very safe and guarantees that your 
                money gets to its intended place on time. For family needs or 
                business purposes, this service ensures that your financial 
                transactions are processed fast enough to meet your current financial 
                needs.
              </p>

              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-gray-700 font-medium">Instant money transfers to any bank</span>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                    <Lock className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-gray-700 font-medium">Bank-level security and encryption</span>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center">
                    <Timer className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-gray-700 font-medium">24/7 availability with real-time processing</span>
                </div>
              </div>

              <button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg">
                Start Transfer Now
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gray-900 via-blue-900 to-indigo-900 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-gray-900/90 via-blue-900/90 to-indigo-900/90"></div>
          <div className="absolute top-20 left-20 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 text-center relative z-10">
          <div className="max-w-4xl mx-auto space-y-8">
            <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
              Get started with SovaPay's DMT services today and experience seamless, convenient money transfers.
            </h2>
            <p className="text-xl text-blue-100 leading-relaxed">
              Join thousands of satisfied customers who trust SovaPay for their money transfer needs. 
              Fast, secure, and reliable - that's our promise to you.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg">
                Contact Us
              </button>
              <button className="border-2 border-white/30 hover:border-white/50 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 hover:bg-white/10 backdrop-blur-sm">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      <style jsx>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .preserve-3d {
          transform-style: preserve-3d;
        }
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          33% { transform: translateY(-8px) translateX(4px) rotateZ(2deg); }
          66% { transform: translateY(4px) translateX(-2px) rotateZ(-1deg); }
        }
        @keyframes float-medium {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          50% { transform: translateY(-12px) translateX(6px) rotateZ(3deg); }
        }
        @keyframes float-fast {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          25% { transform: translateY(-6px) translateX(3px) rotateZ(1deg); }
          75% { transform: translateY(6px) translateX(-3px) rotateZ(-2deg); }
        }
        @keyframes money-flow {
          0% { left: 0; }
          100% { left: calc(100% - 16px); }
        }
        @keyframes coin-bounce {
          0%, 100% { transform: translateY(0px) rotateY(0deg); }
          25% { transform: translateY(-8px) rotateY(90deg); }
          50% { transform: translateY(-4px) rotateY(180deg); }
          75% { transform: translateY(-8px) rotateY(270deg); }
        }
        .animate-float-slow {
          animation: float-slow 6s ease-in-out infinite;
        }
        .animate-float-medium {
          animation: float-medium 4s ease-in-out infinite;
        }
        .animate-float-fast {
          animation: float-fast 3s ease-in-out infinite;
        }
        .animate-money-flow {
          animation: money-flow 3s ease-in-out infinite;
        }
        .animate-coin-bounce {
          animation: coin-bounce 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default DmtServices;