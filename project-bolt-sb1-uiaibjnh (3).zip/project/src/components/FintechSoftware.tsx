import React from 'react';
import { 
  Code, 
  Shield, 
  TrendingUp, 
  CheckCircle,
  ArrowRight,
  Users,
  Building2,
  Smartphone,
  CreditCard,
  Globe,
  Zap,
  DollarSign,
  Star,
  Award,
  Target,
  BarChart3,
  Fingerprint,
  X,
  Monitor,
  Database,
  Cpu,
  Settings
} from 'lucide-react';

const FintechSoftware = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Enhanced Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-64 h-64 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-br from-indigo-200/30 to-blue-200/30 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
          <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-gradient-to-br from-purple-200/20 to-pink-200/20 rounded-full blur-2xl animate-pulse" style={{animationDelay: '4s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-2 bg-blue-100 rounded-full px-4 py-2 border border-blue-200 mb-6">
              <Code className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-700">Advanced Financial Technology</span>
            </div>

            <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              <span className="text-blue-600">Fin-Tech</span><br />
              Softwares
            </h1>
            <p className="text-xl text-gray-700 mb-8">Unlock the Future of Finance with Fintech Software Solutions</p>
            
            {/* Enhanced Fintech Animation */}
            <div className="relative w-full max-w-3xl mx-auto h-96 mb-8">
              <div className="relative w-full h-full perspective-1000">
                {/* Background Gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 to-purple-100/50 rounded-3xl overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-200/20 via-transparent to-purple-200/20"></div>
                </div>

                {/* Main 3D Scene Container */}
                <div className="absolute inset-0 transform-gpu preserve-3d" style={{transform: 'rotateX(10deg) rotateY(-5deg) translateZ(0)'}}>
                  
                  {/* Enhanced Laptop/Computer */}
                  <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-20deg) rotateY(-15deg)'}}>
                      {/* Laptop Shadow */}
                      <div className="absolute top-12 left-12 w-56 h-36 bg-black/15 rounded-xl blur-xl transform skew-x-12 skew-y-6"></div>
                      
                      {/* Laptop Base */}
                      <div className="w-56 h-36 bg-gradient-to-b from-gray-200 via-gray-300 to-gray-400 rounded-xl shadow-2xl border border-gray-300 relative overflow-hidden">
                        {/* Laptop Highlight */}
                        <div className="absolute top-2 left-4 w-16 h-10 bg-white/40 rounded blur-sm"></div>
                        
                        {/* Right Side Panel */}
                        <div className="absolute top-0 -right-6 w-6 h-36 bg-gradient-to-b from-gray-300 to-gray-500 transform skew-y-12 shadow-lg"></div>
                        
                        {/* Top Panel */}
                        <div className="absolute -top-4 left-0 w-56 h-4 bg-gradient-to-r from-gray-200 to-gray-300 transform skew-x-12 shadow-lg"></div>
                        
                        {/* Screen */}
                        <div className="p-4 pt-6">
                          <div className="h-24 bg-gradient-to-b from-blue-600 via-blue-700 to-indigo-800 rounded-lg shadow-inner border border-blue-500 relative overflow-hidden">
                            {/* Screen Glow */}
                            <div className="absolute inset-0 bg-gradient-to-t from-transparent to-white/5"></div>
                            
                            {/* Fintech Dashboard */}
                            <div className="absolute top-2 left-2 right-2">
                              <div className="text-center mb-2">
                                <div className="text-white text-xs font-bold">FINTECH DASHBOARD</div>
                              </div>
                              
                              {/* Chart Area */}
                              <div className="h-10 bg-white/10 rounded flex items-end space-x-1 p-1 mb-2">
                                {[...Array(12)].map((_, i) => (
                                  <div key={i} className={`bg-cyan-400 rounded-sm animate-pulse`} style={{width: '3px', height: `${20 + (i * 6)}%`, animationDelay: `${i * 0.15}s`}}></div>
                                ))}
                              </div>
                              
                              {/* Status Indicators */}
                              <div className="flex justify-between">
                                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" style={{animationDelay: '0.3s'}}></div>
                                <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse" style={{animationDelay: '0.6s'}}></div>
                                <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse" style={{animationDelay: '0.9s'}}></div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {/* Keyboard */}
                        <div className="absolute bottom-2 left-4 right-10 grid grid-cols-12 gap-0.5">
                          {[...Array(36)].map((_, i) => (
                            <div key={i} className="w-1.5 h-1 bg-gray-500 rounded-sm"></div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Floating Code Elements */}
                  <div className="absolute top-16 right-24 animate-float-slow">
                    <div className="relative transform rotate-12">
                      <div className="w-20 h-16 bg-gradient-to-b from-green-500 to-green-700 rounded-lg shadow-xl border border-green-300 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-3 h-3 bg-green-200 rounded-full"></div>
                        <div className="absolute bottom-2 right-2">
                          <Code className="w-4 h-4 text-white" />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                        <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 text-white text-xs font-bold">API</div>
                      </div>
                    </div>
                  </div>

                  <div className="absolute bottom-24 left-8 animate-float-medium" style={{animationDelay: '1s'}}>
                    <div className="relative transform -rotate-12">
                      <div className="w-20 h-16 bg-gradient-to-b from-purple-500 to-purple-700 rounded-lg shadow-xl border border-purple-300 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-3 h-3 bg-purple-200 rounded-full"></div>
                        <div className="absolute bottom-2 right-2">
                          <Shield className="w-4 h-4 text-white" />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                        <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 text-white text-xs font-bold">SEC</div>
                      </div>
                    </div>
                  </div>

                  <div className="absolute top-32 left-24 animate-float-fast" style={{animationDelay: '2s'}}>
                    <div className="relative transform rotate-6">
                      <div className="w-20 h-16 bg-gradient-to-b from-blue-500 to-blue-700 rounded-lg shadow-xl border border-blue-300 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-3 h-3 bg-blue-200 rounded-full"></div>
                        <div className="absolute bottom-2 right-2">
                          <BarChart3 className="w-4 h-4 text-white" />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                        <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 text-white text-xs font-bold">DATA</div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Floating Tech Icons */}
                  <div className="absolute top-20 left-32 animate-float-slow" style={{animationDelay: '0.5s'}}>
                    <div className="w-12 h-12 bg-gradient-to-br from-cyan-400 to-cyan-600 rounded-full shadow-xl flex items-center justify-center">
                      <Database className="w-6 h-6 text-white" />
                    </div>
                  </div>

                  <div className="absolute bottom-20 right-32 animate-float-medium" style={{animationDelay: '1.5s'}}>
                    <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full shadow-xl flex items-center justify-center">
                      <Cpu className="w-6 h-6 text-white" />
                    </div>
                  </div>

                  {/* Enhanced Golden Coins */}
                  <div className="absolute bottom-16 right-16 animate-coin-bounce">
                    <div className="relative">
                      <div className="w-12 h-12 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-lg">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-12 h-3 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  <div className="absolute top-40 right-40 animate-coin-bounce" style={{animationDelay: '0.5s'}}>
                    <div className="relative">
                      <div className="w-10 h-10 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-sm">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-10 h-2 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  {/* Network Connection Lines */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-96 h-96 border border-dashed border-blue-300/30 rounded-full animate-spin opacity-40" style={{animationDuration: '40s'}}></div>
                    <div className="absolute w-80 h-80 border border-dashed border-purple-300/25 rounded-full animate-spin opacity-35" style={{animationDuration: '35s', animationDirection: 'reverse'}}></div>
                  </div>

                  {/* Floating Particles */}
                  <div className="absolute top-24 left-40 w-2 h-2 bg-blue-400 rounded-full animate-ping"></div>
                  <div className="absolute bottom-32 left-48 w-1.5 h-1.5 bg-purple-400 rounded-full animate-ping" style={{animationDelay: '1s'}}></div>
                  <div className="absolute top-48 right-48 w-1 h-1 bg-green-400 rounded-full animate-ping" style={{animationDelay: '2s'}}></div>
                </div>
              </div>
            </div>

            <p className="text-lg text-gray-600 leading-relaxed max-w-4xl mx-auto mb-8">
              At Xettle, we are dedicated to the development of new solutions in the sphere of finance. Our innovative software products in the field of 
              financial technologies help organizations and people to thrive in the modern world of finance.
            </p>

            <button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105 shadow-lg mx-auto">
              <span>Get Started</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Comprehensive Fintech Services Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              <span className="text-blue-600">Comprehensive</span> Fintech Services
            </h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* AePS Solutions */}
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-8 hover:shadow-xl transition-shadow">
              <div className="flex items-start space-x-4 mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <Fingerprint className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">AePS Solutions</h3>
                  <div className="bg-blue-100 rounded-lg px-3 py-1 inline-block mb-3">
                    <span className="text-blue-700 font-semibold text-sm">AEPS</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 leading-relaxed">
                Being an AePS service provider, we provide a strong platform 
                where Aadhaar AePS transactions with the help of Aadhaar. Our 
                services enable business entities to effectively perform their 
                banking needs such as financial transactions, balance 
                enquiries, cash withdrawals, and mini-statements. Our AePS 
                services portfolio and improve access to financial services.
              </p>
            </div>

            {/* BBPS Integration */}
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-8 hover:shadow-xl transition-shadow">
              <div className="flex items-start space-x-4 mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <Zap className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">BBPS Integration</h3>
                  <div className="bg-orange-100 rounded-lg px-3 py-1 inline-block mb-3">
                    <span className="text-orange-700 font-semibold text-sm">BHARAT BILL PAY</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 leading-relaxed">
                We provide various BBPS services that help customers and 
                businesses to pay their bills easily. We offer a comprehensive 
                platform for bill payments that includes electricity, water, gas, 
                telephone and many others. Become our partner and help your 
                customers to pay their bills easily and conveniently and you 
                will increase your revenue.
              </p>
            </div>

            {/* DMT Services */}
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-8 hover:shadow-xl transition-shadow">
              <div className="flex items-start space-x-4 mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <ArrowRight className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">DMT Services</h3>
                </div>
              </div>
              <p className="text-gray-600 leading-relaxed">
                Domestic Money Transfer (DMT) services are very easy and 
                convenient for people to recharge their mobile phones, DTH 
                services, data cards, etc. We offer a friendly interface that can 
                be used by customers to transfer money within the country. We 
                offer a friendly interface that can be used by customers to 
                facilitate financial transactions. Become our partner to diversify 
                your financial services and meet the increasing needs of your 
                customers.
              </p>
            </div>

            {/* Recharge Services */}
            <div className="bg-gradient-to-br from-cyan-50 to-blue-50 rounded-2xl p-8 hover:shadow-xl transition-shadow">
              <div className="flex items-start space-x-4 mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-cyan-500 to-cyan-600 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <Smartphone className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Recharge Services</h3>
                </div>
              </div>
              <p className="text-gray-600 leading-relaxed">
                Our recharge services are very easy and convenient for people 
                to recharge their mobile phones, DTH services, data cards, etc. 
                We provide instant recharge services and commission for every 
                recharge. We provide instant recharge services and commission 
                for every recharge. Become our partner to offer your customers 
                the range of our services and meet the increasing needs of 
                mobile and DTH recharges.
              </p>
            </div>

            {/* Aadhaar and PAN Verification */}
            <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-2xl p-8 hover:shadow-xl transition-shadow lg:col-span-2">
              <div className="flex items-start space-x-4 mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center flex-shrink-0">
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Aadhaar and PAN Verification</h3>
                  <div className="bg-red-100 rounded-lg px-3 py-1 inline-block mb-3">
                    <span className="text-red-700 font-semibold text-sm">PAN</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 leading-relaxed">
                The Aadhaar/PAN verification services offered by us are efficient and effective methods of verifying people 
                and companies. We provide a strong platform for instant Aadhaar and PAN card checks, for compliance, 
                onboarding, and risk management. Our verification services are fast, accurate, and secure, helping you 
                to get the best verification solutions that you can rely on.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              <span className="text-blue-600">Packages</span>
            </h2>
          </div>

          {/* B2B Packages */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-gray-900 mb-8">B2B</h3>
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Standard Package */}
              <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                <div className="text-center mb-8">
                  <h4 className="text-xl font-bold text-gray-900 mb-2">Standard</h4>
                </div>
                <div className="space-y-4">
                  {[
                    { name: 'AePS', included: true },
                    { name: 'BBPS', included: true },
                    { name: 'Account Opening', included: true },
                    { name: 'Offline Market Share', included: true },
                    { name: 'UPI Collection', included: true },
                    { name: 'PAN UTI Software', included: false },
                    { name: 'NSDL Portal', included: false },
                    { name: 'Domestic Money Transfer', included: false },
                    { name: 'Hotel Booking Portal', included: false },
                    { name: 'Bus Booking Portal', included: false },
                    { name: 'Flight Booking Portal', included: false },
                    { name: 'Account Opening', included: false },
                    { name: 'Multi Recharge', included: false }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-gray-700">{item.name}</span>
                      {item.included ? (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      ) : (
                        <X className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Premium Package */}
              <div className="bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow text-white relative overflow-hidden">
                <div className="absolute top-4 right-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                  Premium
                </div>
                <div className="text-center mb-8">
                  <h4 className="text-xl font-bold mb-2">Premium</h4>
                </div>
                <div className="space-y-4">
                  {[
                    'AePS',
                    'BBPS',
                    'Account Opening',
                    'Offline Market Share',
                    'UPI Collection',
                    'PAN UTI Software',
                    'NSDL Portal',
                    'Domestic Money Transfer',
                    'Hotel Booking Portal',
                    'Bus Booking Portal',
                    'Flight Booking Portal',
                    'Account Opening',
                    'Multi Recharge'
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span>{item}</span>
                      <CheckCircle className="w-5 h-5 text-green-400" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Reseller Packages */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-gray-900 mb-8">Reseller</h3>
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Standard Reseller */}
              <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                <div className="text-center mb-8">
                  <h4 className="text-xl font-bold text-gray-900 mb-2">Standard</h4>
                </div>
                <div className="space-y-4">
                  {[
                    { name: 'BBPC', included: true },
                    { name: 'EPS', included: true },
                    { name: 'Account Opening', included: true },
                    { name: 'Offline Market Share', included: false },
                    { name: 'UPI Collection', included: true },
                    { name: 'PAN UTI Software', included: true },
                    { name: 'NSDL Portal', included: true },
                    { name: 'Domestic Money Transfer', included: true },
                    { name: 'Hotel Booking Portal', included: true },
                    { name: 'Bus Booking Portal', included: false },
                    { name: 'Flight Booking Portal', included: false }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-gray-700">{item.name}</span>
                      {item.included ? (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      ) : (
                        <X className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Premium Reseller */}
              <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow text-white relative overflow-hidden">
                <div className="absolute top-4 right-4 bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                  Premium
                </div>
                <div className="text-center mb-8">
                  <h4 className="text-xl font-bold mb-2">Premium</h4>
                </div>
                <div className="space-y-4">
                  {[
                    'BBPC',
                    'EPS',
                    'Account Opening',
                    'Offline Market Share',
                    'UPI Collection',
                    'PAN UTI Software',
                    'NSDL Portal',
                    'Domestic Money Transfer',
                    'Hotel Booking Portal',
                    'Bus Booking Portal',
                    'Flight Booking Portal'
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span>{item}</span>
                      <CheckCircle className="w-5 h-5 text-green-400" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* B2C Package */}
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-8">B2C</h3>
            <div className="max-w-md mx-auto">
              <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                <div className="text-center mb-8">
                  <h4 className="text-xl font-bold text-gray-900 mb-2">B2C Package</h4>
                </div>
                <div className="space-y-4">
                  {[
                    'BBPC',
                    'Hotel Booking Portal',
                    'Bus Booking Portal',
                    'Flight Booking Portal',
                    'Multi Recharge'
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-gray-700">{item}</span>
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </div>
                  ))}
                </div>
                <div className="mt-8 flex space-x-4">
                  <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors">
                    Contact Us
                  </button>
                  <button className="flex-1 border-2 border-gray-300 hover:border-gray-400 text-gray-700 px-6 py-3 rounded-lg font-semibold transition-colors">
                    Contact Sales
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gray-900 via-blue-900 to-indigo-900 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-gray-900/90 via-blue-900/90 to-indigo-900/90"></div>
          <div className="absolute top-20 left-20 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 text-center relative z-10">
          <div className="max-w-4xl mx-auto space-y-8">
            <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
              Ready to Transform Your Financial Services?
            </h2>
            <p className="text-xl text-blue-100 leading-relaxed">
              Join thousands of businesses who trust SovaPay for their fintech software solutions. 
              Get started today and unlock the future of finance.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg">
                Get Started Now
              </button>
              <button className="border-2 border-white/30 hover:border-white/50 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 hover:bg-white/10 backdrop-blur-sm">
                Schedule Demo
              </button>
            </div>
          </div>
        </div>
      </section>

      <style jsx>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .preserve-3d {
          transform-style: preserve-3d;
        }
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          33% { transform: translateY(-8px) translateX(4px) rotateZ(2deg); }
          66% { transform: translateY(4px) translateX(-2px) rotateZ(-1deg); }
        }
        @keyframes float-medium {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          50% { transform: translateY(-12px) translateX(6px) rotateZ(3deg); }
        }
        @keyframes float-fast {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          25% { transform: translateY(-6px) translateX(3px) rotateZ(1deg); }
          75% { transform: translateY(6px) translateX(-3px) rotateZ(-2deg); }
        }
        @keyframes coin-bounce {
          0%, 100% { transform: translateY(0px) rotateY(0deg); }
          25% { transform: translateY(-8px) rotateY(90deg); }
          50% { transform: translateY(-4px) rotateY(180deg); }
          75% { transform: translateY(-8px) rotateY(270deg); }
        }
        .animate-float-slow {
          animation: float-slow 6s ease-in-out infinite;
        }
        .animate-float-medium {
          animation: float-medium 4s ease-in-out infinite;
        }
        .animate-float-fast {
          animation: float-fast 3s ease-in-out infinite;
        }
        .animate-coin-bounce {
          animation: coin-bounce 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default FintechSoftware;