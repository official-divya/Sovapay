import React from 'react';
import { CreditCard, Facebook, Instagram, Twitter, Linkedin, MapPin, Phone, Mail } from 'lucide-react';

interface FooterProps {
  setCurrentPage: (page: string) => void;
}

const Footer = ({ setCurrentPage }: FooterProps) => {
  return (
    <footer className="bg-gradient-to-r from-gray-900 via-blue-900 to-indigo-900 text-white">
      <div className="container mx-auto px-6 py-16">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-12">
          {/* Company Info */}
          <div className="space-y-6">
            <div className="flex items-center space-x-2">
               <img src="/sovapaylogo.svg" alt="SovaPay Logo" className="h-10 w-auto" />
            </div>
            <p className="text-gray-300 leading-relaxed">
              This is the place where quality meets innovation. Discover revolutionary solutions 
              that will transform the way you deliver value to your customers, quickly and easily.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Services */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold">Services</h3>
            <div className="space-y-3">
              <button onClick={() => setCurrentPage('aeps')} className="block text-gray-300 hover:text-white transition-colors text-left">AePS Services</button>
              <button onClick={() => setCurrentPage('utility')} className="block text-gray-300 hover:text-white transition-colors text-left">Utility Payment Solutions</button>
              <button onClick={() => setCurrentPage('dmt')} className="block text-gray-300 hover:text-white transition-colors text-left">Domestic Money Transfer</button>
              <button onClick={() => setCurrentPage('micro-atm')} className="block text-gray-300 hover:text-white transition-colors text-left">Micro ATM</button>
              <button onClick={() => setCurrentPage('fintech-software')} className="block text-gray-300 hover:text-white transition-colors text-left">Fin-Tech Software</button>
              <button onClick={() => setCurrentPage('payout-solutions')} className="block text-gray-300 hover:text-white transition-colors text-left">Payout Solutions</button>
              <button onClick={() => setCurrentPage('kyc-verification')} className="block text-gray-300 hover:text-white transition-colors text-left">KYC and Validation</button>
            </div>
          </div>

          {/* Helpful Links */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold">Helpful Links</h3>
            <div className="space-y-3">
              <button onClick={() => setCurrentPage('about')} className="block text-gray-300 hover:text-white transition-colors text-left">About Us</button>
              <button onClick={() => setCurrentPage('contact')} className="block text-gray-300 hover:text-white transition-colors text-left">Contact Us</button>
              <button onClick={() => setCurrentPage('privacy')} className="block text-gray-300 hover:text-white transition-colors text-left">Privacy Policy</button>
              <button onClick={() => setCurrentPage('terms')} className="block text-gray-300 hover:text-white transition-colors text-left">Terms & Conditions</button>
              <button onClick={() => setCurrentPage('contact')} className="block text-gray-300 hover:text-white transition-colors text-left">Customer Grievances</button>
            </div>
          </div>

          {/* Contact */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold">Contact</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <Mail className="w-5 h-5 text-blue-400 mt-1" />
                <span className="text-gray-300">letask@sovapay.net</span>
              </div>
              <div className="flex items-start space-x-3">
                <Phone className="w-5 h-5 text-blue-400 mt-1" />
                <span className="text-gray-300">+91 9654607040</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-blue-400 mt-1" />
                <span className="text-gray-300">
                  44 IIND FLOOR REGAL BUILDING,<br />
                  CONNAUGHT PLACE, NEW DELHI
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/20 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-gray-400 text-sm">© 2025 SovaPay Technologies</p>
            <div className="flex space-x-6 text-sm">
              <span className="text-gray-400">All rights reserved</span>
              <button onClick={() => setCurrentPage('terms')} className="text-gray-400 hover:text-white transition-colors">Terms & Conditions</button>
              <button onClick={() => setCurrentPage('privacy')} className="text-gray-400 hover:text-white transition-colors">Privacy Policy</button>
              <button onClick={() => setCurrentPage('contact')} className="text-gray-400 hover:text-white transition-colors">Customer Grievances</button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;