import React, { useState } from 'react';
import { CreditCard, Menu, X, ChevronDown, Fingerprint, Wifi, Send, Tablet, Code, Banknote, UserCheck } from 'lucide-react';

interface HeaderProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
}

const Header = ({ currentPage, setCurrentPage }: HeaderProps) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const [isCompanyOpen, setIsCompanyOpen] = useState(false);

  const handleServicesMouseEnter = () => setIsServicesOpen(true);
  const handleServicesMouseLeave = () => setIsServicesOpen(false);
  const handleCompanyMouseEnter = () => setIsCompanyOpen(true);
  const handleCompanyMouseLeave = () => setIsCompanyOpen(false);

  return (
    <header className="bg-gradient-to-r from-purple-900 via-blue-900 to-indigo-900 text-white relative">
      <nav className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <img src="/sovapaylogo.svg" alt="SovaPay Logo" className="h-10 w-auto" />
          </div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            <button 
              onClick={() => setCurrentPage('home')}
              className={`hover:text-purple-300 transition-colors ${currentPage === 'home' ? 'text-purple-300' : ''}`}
            >
              HOME
            </button>
            
            {/* Services Dropdown */}
            <div className="relative">
              <button 
                className="flex items-center space-x-1 hover:text-purple-300 transition-colors"
                onMouseEnter={handleServicesMouseEnter}
                onMouseLeave={handleServicesMouseLeave}
              >
                <span>SERVICES</span>
                <ChevronDown className="w-4 h-4" />
              </button>
              {isServicesOpen && (
                <div 
                  className="absolute top-full centre-0 mt-2 w-[750px] bg-white text-gray-800 rounded-xl shadow-2xl z-50 p-6 border border-gray-100"
                  onMouseEnter={handleServicesMouseEnter}
                  onMouseLeave={handleServicesMouseLeave}
                >
                  <div className="grid grid-cols-2 gap-6">
                    <div 
                      className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer"
                      onClick={() => {
                        setCurrentPage('aeps');
                        setIsServicesOpen(false);
                      }}
                    >
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Fingerprint className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm text-gray-900 mb-1">AePS Services</h3>
                        <p className="text-xs text-gray-500 leading-relaxed">Empowering transactions with seamless AEPS service for banking needs</p>
                      </div>
                    </div>
                    
                    <div 
                      className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer"
                      onClick={() => {
                        setCurrentPage('utility');
                        setIsServicesOpen(false);
                      }}
                    >
                      <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Wifi className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm text-gray-900 mb-1">Utility Payment Solutions</h3>
                        <p className="text-xs text-gray-500 leading-relaxed">Comprehensive BBPS service for seamless bill payments and recharges</p>
                      </div>
                    </div>
                    
                    <div 
                      className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer"
                      onClick={() => {
                        setCurrentPage('dmt');
                        setIsServicesOpen(false);
                      }}
                    >
                      <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Send className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm text-gray-900 mb-1">Domestic Money Transfer</h3>
                        <p className="text-xs text-gray-500 leading-relaxed">Instant domestic money transfers for seamless, quick financial transactions</p>
                      </div>
                    </div>
                    
                    <div 
                      className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer"
                      onClick={() => {
                        setCurrentPage('micro-atm');
                        setIsServicesOpen(false);
                      }}
                    >
                      <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Tablet className="w-5 h-5 text-orange-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm text-gray-900 mb-1">Micro ATM</h3>
                        <p className="text-xs text-gray-500 leading-relaxed">Portable mATM for cash withdrawals and balance inquiries</p>
                      </div>
                    </div>
                    
                    <div 
                      className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer"
                      onClick={() => {
                        setCurrentPage('fintech-software');
                        setIsServicesOpen(false);
                      }}
                    >
                      <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Code className="w-5 h-5 text-indigo-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm text-gray-900 mb-1">Fin-Tech Software</h3>
                        <p className="text-xs text-gray-500 leading-relaxed">Crafting innovative financial technology solutions for modern businesses</p>
                      </div>
                    </div>
                    
                    <div 
                      className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer"
                      onClick={() => {
                        setCurrentPage('payout-solutions');
                        setIsServicesOpen(false);
                      }}
                    >
                      <div className="w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Banknote className="w-5 h-5 text-cyan-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm text-gray-900 mb-1">Payout Solutions</h3>
                        <p className="text-xs text-gray-500 leading-relaxed">Streamlined payouts for efficient financial transactions and disbursements</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6 pt-4 border-t border-gray-100">
                    <div 
                      className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer"
                      onClick={() => {
                        setCurrentPage('kyc-verification');
                        setIsServicesOpen(false);
                      }}
                    >
                      <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <UserCheck className="w-5 h-5 text-red-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-sm text-gray-900 mb-1">KYC and Validation</h3>
                        <p className="text-xs text-gray-500 leading-relaxed">Implementing secure Know Your Customer (KYC) and validation services</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Company Dropdown */}
            <div className="relative">
              <button 
                className="flex items-center space-x-1 hover:text-purple-300 transition-colors"
                onMouseEnter={handleCompanyMouseEnter}
                onMouseLeave={handleCompanyMouseLeave}
              >
                <span>COMPANY</span>
                <ChevronDown className="w-4 h-4" />
              </button>
              {isCompanyOpen && (
                <div 
                  className="absolute top-full left-0 mt-2 w-80 bg-white text-gray-800 rounded-lg shadow-xl z-50 p-4"
                  onMouseEnter={handleCompanyMouseEnter}
                  onMouseLeave={handleCompanyMouseLeave}
                >
                    <button 
                      onClick={() => {
                        setCurrentPage('about');
                        setIsCompanyOpen(false);
                      }}
                      className="block w-full text-left px-3 py-2 hover:bg-gray-50 rounded-lg text-sm"
                    >
                      About Us
                    </button>
                    <button 
                      onClick={() => {
                        setCurrentPage('contact');
                        setIsCompanyOpen(false);
                      }}
                      className="block w-full text-left px-3 py-2 hover:bg-gray-50 rounded-lg text-sm"
                    >
                      Contact Us
                    </button>
                    <button 
                      onClick={() => {
                        setCurrentPage('privacy');
                        setIsCompanyOpen(false);
                      }}
                      className="block w-full text-left px-3 py-2 hover:bg-gray-50 rounded-lg text-sm"
                    >
                      Privacy Policy
                    </button>
                    <button 
                      onClick={() => {
                        setCurrentPage('terms');
                        setIsCompanyOpen(false);
                      }}
                      className="block w-full text-left px-3 py-2 hover:bg-gray-50 rounded-lg text-sm"
                    >
                      Terms & Conditions
                    </button>
                  </div>
              )}
            </div>

            <a href="#blogs" className="hover:text-purple-300 transition-colors">BLOGS</a>
          </div>

          {/* CTA Buttons */}
          <div className="hidden lg:flex items-center space-x-4">
            <button 
              onClick={() => setCurrentPage('contact')}
              className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 px-6 py-2 rounded-full font-semibold transition-all duration-300 transform hover:scale-105"
            >
              GET STARTED
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="lg:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden mt-4 pb-4">
            <div className="flex flex-col space-y-4">
              <button 
                onClick={() => {
                  setCurrentPage('home');
                  setIsMenuOpen(false);
                }}
                className="hover:text-purple-300 transition-colors text-left"
              >
                HOME
              </button>
              <a href="#services" className="hover:text-purple-300 transition-colors">SERVICES</a>
              <a href="#company" className="hover:text-purple-300 transition-colors">COMPANY</a>
              <a href="#blogs" className="hover:text-purple-300 transition-colors">BLOGS</a>
              <div className="flex flex-col space-y-2 pt-4 border-t border-purple-700">
                <button className="bg-gradient-to-r from-purple-500 to-blue-500 px-6 py-2 rounded-full font-semibold text-left">
                  GET STARTED
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;