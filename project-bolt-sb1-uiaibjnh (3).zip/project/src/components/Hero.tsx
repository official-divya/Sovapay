import React from 'react';
import { SetStateAction } from 'react';
import { CheckCircle, ArrowRight, Play } from 'lucide-react';

interface HeroProps {
  setCurrentPage: (page: string) => void;
}

const Hero = ({ setCurrentPage }: HeroProps) => {
  return (
    <section className="bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white py-20 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-32 h-32 bg-purple-400 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-blue-400 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/3 w-24 h-24 bg-indigo-400 rounded-full blur-2xl"></div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            {/* Badge */}
            {/* Main Heading */}
            <div className="space-y-4">
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                Innovations in{' '}
                <span className="bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                  Software, Fintech, and Beyond
                </span>
              </h1>
              
              <p className="text-xl text-gray-300 leading-relaxed max-w-2xl">
               Sovapay mission is to drive financial inclusion by delivering secure and efficient digital solutions. Through services like Micro ATMs, KYC, and identity verification, Savapay empowers individuals and businesses to easily access essential banking and financial services.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={() => setCurrentPage('contact')}
                className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                <span>Gets Started</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>

            {/* Trust Indicators */}
            <div className="flex items-center space-x-8 pt-8">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-sm text-gray-300">Quick Onboarding</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-sm text-gray-300">99% Success Rate</span>
              </div>
            </div>
          </div>

          {/* Right Content - Isometric Fintech Animation */}
          <div className="relative">
            {/* Enhanced Isometric Scene */}
            <div className="relative w-full h-[500px] perspective-1000">
              {/* Background Gradient Orbs */}
              <div className="absolute inset-0 overflow-hidden rounded-3xl">
                <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-400/20 to-cyan-400/20 rounded-full blur-3xl animate-pulse"></div>
                <div className="absolute bottom-0 right-0 w-80 h-80 bg-gradient-to-br from-purple-400/20 to-pink-400/20 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-br from-indigo-400/15 to-blue-400/15 rounded-full blur-2xl animate-pulse" style={{animationDelay: '2s'}}></div>
              </div>

              {/* Main Isometric Container */}
              <div className="absolute inset-0 transform-gpu preserve-3d" style={{transform: 'rotateX(15deg) rotateY(-15deg) translateZ(0)'}}>
                
                {/* Enhanced Floating Cubes with Realistic Shadows */}
                <div className="absolute top-16 left-20 animate-float-slow" style={{animationDelay: '0s'}}>
                  <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-25deg) rotateY(35deg) rotateZ(5deg)'}}>
                    {/* Cube Shadow */}
                    <div className="absolute top-8 left-8 w-16 h-16 bg-black/10 rounded-lg blur-sm transform skew-x-12 skew-y-6"></div>
                    {/* Main Cube */}
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-400 via-blue-500 to-blue-700 rounded-lg shadow-2xl relative overflow-hidden">
                      {/* Cube Highlight */}
                      <div className="absolute top-1 left-1 w-6 h-6 bg-white/30 rounded blur-sm"></div>
                      {/* Cube Pattern */}
                      <div className="absolute inset-2 border border-white/20 rounded"></div>
                      {/* Right Side */}
                      <div className="absolute top-0 -right-4 w-4 h-16 bg-gradient-to-b from-blue-600 to-blue-900 transform skew-y-12 shadow-lg"></div>
                      {/* Top Side */}
                      <div className="absolute -top-4 left-0 w-16 h-4 bg-gradient-to-r from-blue-300 to-blue-500 transform skew-x-12 shadow-lg"></div>
                    </div>
                  </div>
                </div>

                <div className="absolute top-12 right-24 animate-float-medium" style={{animationDelay: '1.5s'}}>
                  <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-30deg) rotateY(40deg) rotateZ(-10deg)'}}>
                    <div className="absolute top-6 left-6 w-12 h-12 bg-black/10 rounded-lg blur-sm transform skew-x-12 skew-y-6"></div>
                    <div className="w-12 h-12 bg-gradient-to-br from-cyan-400 via-cyan-500 to-cyan-700 rounded-lg shadow-2xl relative overflow-hidden">
                      <div className="absolute top-1 left-1 w-4 h-4 bg-white/30 rounded blur-sm"></div>
                      <div className="absolute inset-1.5 border border-white/20 rounded"></div>
                      <div className="absolute top-0 -right-3 w-3 h-12 bg-gradient-to-b from-cyan-600 to-cyan-900 transform skew-y-12 shadow-lg"></div>
                      <div className="absolute -top-3 left-0 w-12 h-3 bg-gradient-to-r from-cyan-300 to-cyan-500 transform skew-x-12 shadow-lg"></div>
                    </div>
                  </div>
                </div>

                <div className="absolute bottom-24 left-16 animate-float-fast" style={{animationDelay: '3s'}}>
                  <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-20deg) rotateY(30deg) rotateZ(15deg)'}}>
                    <div className="absolute top-7 left-7 w-14 h-14 bg-black/10 rounded-lg blur-sm transform skew-x-12 skew-y-6"></div>
                    <div className="w-14 h-14 bg-gradient-to-br from-indigo-400 via-indigo-500 to-indigo-700 rounded-lg shadow-2xl relative overflow-hidden">
                      <div className="absolute top-1 left-1 w-5 h-5 bg-white/30 rounded blur-sm"></div>
                      <div className="absolute inset-2 border border-white/20 rounded"></div>
                      <div className="absolute top-0 -right-3.5 w-3.5 h-14 bg-gradient-to-b from-indigo-600 to-indigo-900 transform skew-y-12 shadow-lg"></div>
                      <div className="absolute -top-3.5 left-0 w-14 h-3.5 bg-gradient-to-r from-indigo-300 to-indigo-500 transform skew-x-12 shadow-lg"></div>
                    </div>
                  </div>
                </div>

                {/* Premium Server Rack */}
                <div className="absolute right-16 top-1/2 transform -translate-y-1/2">
                  <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-20deg) rotateY(-25deg)'}}>
                    {/* Server Shadow */}
                    <div className="absolute top-12 left-12 w-24 h-40 bg-black/15 rounded-xl blur-lg transform skew-x-6 skew-y-12"></div>
                    
                    {/* Main Server Body */}
                    <div className="w-24 h-40 bg-gradient-to-b from-slate-700 via-slate-800 to-slate-900 rounded-xl shadow-2xl relative overflow-hidden border border-slate-600">
                      {/* Server Glow Effect */}
                      <div className="absolute inset-0 bg-gradient-to-b from-blue-500/10 to-transparent"></div>
                      
                      {/* Right Side Panel */}
                      <div className="absolute top-0 -right-6 w-6 h-40 bg-gradient-to-b from-slate-800 to-black transform skew-y-12 shadow-xl border-r border-slate-700"></div>
                      
                      {/* Top Panel */}
                      <div className="absolute -top-5 left-0 w-24 h-5 bg-gradient-to-r from-slate-600 to-slate-700 transform skew-x-12 shadow-xl border-b border-slate-600"></div>
                      
                      {/* Server Rack Panels */}
                      <div className="p-3 space-y-2">
                        {[...Array(8)].map((_, i) => (
                          <div key={i} className="h-4 bg-gradient-to-r from-slate-600 to-slate-700 rounded-sm shadow-inner border border-slate-500 flex items-center px-2" style={{animationDelay: `${i * 0.2}s`}}>
                            <div className={`w-2 h-2 rounded-full mr-2 animate-pulse ${i % 3 === 0 ? 'bg-green-400' : i % 3 === 1 ? 'bg-blue-400' : 'bg-yellow-400'}`}></div>
                            <div className="flex-1 h-1 bg-slate-400 rounded"></div>
                            <div className="w-1 h-1 bg-slate-300 rounded-full ml-1"></div>
                          </div>
                        ))}
                      </div>
                      
                      {/* Server Vents */}
                      <div className="absolute bottom-2 left-2 right-8 flex space-x-1">
                        {[...Array(6)].map((_, i) => (
                          <div key={i} className="w-1 h-6 bg-slate-600 rounded-full"></div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Premium Mobile Device */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-15deg) rotateY(20deg)'}}>
                    {/* Phone Shadow */}
                    <div className="absolute top-8 left-8 w-20 h-36 bg-black/20 rounded-2xl blur-lg transform skew-x-6 skew-y-6"></div>
                    
                    {/* Phone Body */}
                    <div className="w-20 h-36 bg-gradient-to-b from-slate-800 to-slate-900 rounded-2xl shadow-2xl border-2 border-slate-700 relative overflow-hidden">
                      {/* Phone Highlight */}
                      <div className="absolute top-1 left-1 w-4 h-8 bg-white/10 rounded-lg blur-sm"></div>
                      
                      {/* Side Panel */}
                      <div className="absolute top-0 -right-2 w-2 h-36 bg-gradient-to-b from-slate-900 to-black transform skew-y-6 shadow-lg"></div>
                      
                      <div className="p-2 pt-3">
                        {/* Screen */}
                        <div className="h-28 bg-gradient-to-br from-purple-600 via-purple-700 to-indigo-800 rounded-xl relative overflow-hidden shadow-inner border border-purple-500">
                          {/* Screen Glow */}
                          <div className="absolute inset-0 bg-gradient-to-t from-transparent to-white/5"></div>
                          
                          {/* App Interface */}
                          <div className="absolute top-3 left-3 right-3">
                            {/* Header */}
                            <div className="h-1 bg-white/50 rounded mb-2"></div>
                            <div className="h-1 bg-white/40 rounded w-3/4 mb-3"></div>
                            
                            {/* Progress Indicators */}
                            <div className="space-y-2">
                              <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                                <div className="h-1 bg-green-400 rounded w-4/5"></div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" style={{animationDelay: '0.5s'}}></div>
                                <div className="h-1 bg-blue-400 rounded w-3/5"></div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse" style={{animationDelay: '1s'}}></div>
                                <div className="h-1 bg-yellow-400 rounded w-2/3"></div>
                              </div>
                            </div>
                            
                            {/* Chart Area */}
                            <div className="mt-3 h-8 bg-white/10 rounded flex items-end space-x-1 p-1">
                              {[...Array(8)].map((_, i) => (
                                <div key={i} className={`bg-cyan-400 rounded-sm animate-pulse`} style={{width: '3px', height: `${20 + (i * 5)}%`, animationDelay: `${i * 0.2}s`}}></div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Enhanced Golden Coin Stack */}
                    <div className="absolute -top-4 -right-6 animate-coin-spin">
                      <div className="relative">
                        {/* Coin Glow */}
                        <div className="absolute inset-0 w-12 h-12 bg-yellow-400/30 rounded-full blur-lg"></div>
                        
                        {/* Main Coin */}
                        <div className="w-12 h-12 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-2xl border-3 border-yellow-200 flex items-center justify-center relative overflow-hidden">
                          {/* Coin Highlight */}
                          <div className="absolute top-1 left-2 w-4 h-4 bg-white/40 rounded-full blur-sm"></div>
                          {/* Currency Symbol */}
                          <span className="text-white font-bold text-lg drop-shadow-lg">₹</span>
                        </div>
                        
                        {/* Coin Stack Layers */}
                        <div className="absolute -bottom-1 left-0 w-12 h-3 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full shadow-lg"></div>
                        <div className="absolute -bottom-2 left-0 w-12 h-3 bg-gradient-to-r from-yellow-600 to-orange-700 rounded-full shadow-lg"></div>
                        <div className="absolute -bottom-3 left-0 w-12 h-3 bg-gradient-to-r from-yellow-700 to-orange-800 rounded-full shadow-lg"></div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Enhanced Tablet/Card Reader */}
                <div className="absolute left-12 bottom-16">
                  <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-35deg) rotateY(-20deg)'}}>
                    {/* Device Shadow */}
                    <div className="absolute top-6 left-6 w-32 h-20 bg-black/15 rounded-xl blur-lg transform skew-x-12 skew-y-6"></div>
                    
                    {/* Device Body */}
                    <div className="w-32 h-20 bg-gradient-to-br from-gray-100 to-gray-300 rounded-xl shadow-2xl border border-gray-200 relative overflow-hidden">
                      {/* Device Highlight */}
                      <div className="absolute top-1 left-2 w-8 h-4 bg-white/60 rounded blur-sm"></div>
                      
                      {/* Right Side */}
                      <div className="absolute top-0 -right-3 w-3 h-20 bg-gradient-to-b from-gray-200 to-gray-400 transform skew-y-12 shadow-lg"></div>
                      
                      {/* Top Side */}
                      <div className="absolute -top-3 left-0 w-32 h-3 bg-gradient-to-r from-gray-50 to-gray-200 transform skew-x-12 shadow-lg"></div>
                      
                      <div className="p-3">
                        {/* Screen Header */}
                        <div className="h-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded mb-2"></div>
                        
                        {/* Status Indicators */}
                        <div className="flex space-x-2 mb-2">
                          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                          <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse" style={{animationDelay: '0.3s'}}></div>
                          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" style={{animationDelay: '0.6s'}}></div>
                        </div>
                        
                        {/* Content Lines */}
                        <div className="space-y-1">
                          <div className="h-1 bg-gray-500 rounded"></div>
                          <div className="h-1 bg-gray-500 rounded w-4/5"></div>
                          <div className="h-1 bg-gray-500 rounded w-3/5"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Enhanced Router/Network Device */}
                <div className="absolute bottom-12 right-8">
                  <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-25deg) rotateY(30deg)'}}>
                    {/* Device Shadow */}
                    <div className="absolute top-4 left-4 w-16 h-10 bg-black/15 rounded-lg blur-md transform skew-x-12 skew-y-6"></div>
                    
                    {/* Device Body */}
                    <div className="w-16 h-10 bg-gradient-to-br from-white to-gray-200 rounded-lg shadow-xl border border-gray-300 relative overflow-hidden">
                      {/* Device Highlight */}
                      <div className="absolute top-0.5 left-1 w-4 h-2 bg-white/80 rounded blur-sm"></div>
                      
                      {/* Right Side */}
                      <div className="absolute top-0 -right-2 w-2 h-10 bg-gradient-to-b from-gray-100 to-gray-300 transform skew-y-12 shadow-lg"></div>
                      
                      {/* Top Side */}
                      <div className="absolute -top-2 left-0 w-16 h-2 bg-gradient-to-r from-gray-50 to-gray-100 transform skew-x-12 shadow-lg"></div>
                      
                      <div className="p-2">
                        {/* Status LEDs */}
                        <div className="flex space-x-1 mb-2">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse shadow-lg"></div>
                          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse shadow-lg" style={{animationDelay: '0.4s'}}></div>
                          <div className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-pulse shadow-lg" style={{animationDelay: '0.8s'}}></div>
                          <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse shadow-lg" style={{animationDelay: '1.2s'}}></div>
                        </div>
                        
                        {/* Device Info */}
                        <div className="space-y-0.5">
                          <div className="h-0.5 bg-gray-500 rounded"></div>
                          <div className="h-0.5 bg-gray-500 rounded w-3/4"></div>
                          <div className="h-0.5 bg-gray-500 rounded w-1/2"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Enhanced Network Connections */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  {/* Outer Ring */}
                  <div className="w-96 h-96 border-2 border-dashed border-blue-300/30 rounded-full animate-spin opacity-40" style={{animationDuration: '40s'}}></div>
                  {/* Middle Ring */}
                  <div className="absolute w-80 h-80 border border-dashed border-purple-300/25 rounded-full animate-spin opacity-35" style={{animationDuration: '35s', animationDirection: 'reverse'}}></div>
                  {/* Inner Ring */}
                  <div className="absolute w-64 h-64 border border-dashed border-cyan-300/20 rounded-full animate-spin opacity-30" style={{animationDuration: '30s'}}></div>
                </div>

                {/* Enhanced Floating Particles */}
                <div className="absolute top-20 left-32 w-2 h-2 bg-blue-400 rounded-full animate-ping shadow-lg"></div>
                <div className="absolute bottom-32 left-40 w-1.5 h-1.5 bg-purple-400 rounded-full animate-ping shadow-lg" style={{animationDelay: '1s'}}></div>
                <div className="absolute top-32 right-40 w-1 h-1 bg-cyan-400 rounded-full animate-ping shadow-lg" style={{animationDelay: '2s'}}></div>
                <div className="absolute bottom-40 right-24 w-2 h-2 bg-green-400 rounded-full animate-ping shadow-lg" style={{animationDelay: '3s'}}></div>
                <div className="absolute top-40 left-24 w-1.5 h-1.5 bg-yellow-400 rounded-full animate-ping shadow-lg" style={{animationDelay: '4s'}}></div>

                {/* Data Flow Lines */}
                <div className="absolute top-1/4 left-1/4 w-32 h-0.5 bg-gradient-to-r from-transparent via-blue-400 to-transparent animate-pulse opacity-60"></div>
                <div className="absolute bottom-1/4 right-1/4 w-24 h-0.5 bg-gradient-to-r from-transparent via-purple-400 to-transparent animate-pulse opacity-60" style={{animationDelay: '1s'}}></div>
                <div className="absolute top-1/2 right-1/3 w-20 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-pulse opacity-60" style={{animationDelay: '2s'}}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <style jsx>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .preserve-3d {
          transform-style: preserve-3d;
        }
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          33% { transform: translateY(-8px) translateX(4px) rotateZ(2deg); }
          66% { transform: translateY(4px) translateX(-2px) rotateZ(-1deg); }
        }
        @keyframes float-medium {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          50% { transform: translateY(-12px) translateX(6px) rotateZ(3deg); }
        }
        @keyframes float-fast {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          25% { transform: translateY(-6px) translateX(3px) rotateZ(1deg); }
          75% { transform: translateY(6px) translateX(-3px) rotateZ(-2deg); }
        }
        @keyframes coin-spin {
          0% { transform: rotateY(0deg) rotateX(0deg); }
          25% { transform: rotateY(90deg) rotateX(10deg); }
          50% { transform: rotateY(180deg) rotateX(0deg); }
          75% { transform: rotateY(270deg) rotateX(-10deg); }
          100% { transform: rotateY(360deg) rotateX(0deg); }
        }
        .animate-float-slow {
          animation: float-slow 6s ease-in-out infinite;
        }
        .animate-float-medium {
          animation: float-medium 4s ease-in-out infinite;
        }
        .animate-float-fast {
          animation: float-fast 3s ease-in-out infinite;
        }
        .animate-coin-spin {
          animation: coin-spin 4s ease-in-out infinite;
        }
        .border-3 {
          border-width: 3px;
        }
      `}</style>
    </section>
  );
};

export default Hero;