import React from 'react';
import { 
  Shield, 
  UserCheck, 
  FileCheck, 
  CheckCircle,
  ArrowRight,
  Users,
  Building2,
  Smartphone,
  CreditCard,
  Globe,
  Zap,
  DollarSign,
  Star,
  Award,
  Target,
  BarChart3,
  Fingerprint,
  Lock,
  Eye,
  Database,
  Settings,
  Search,
  Clock,
  TrendingUp
} from 'lucide-react';

const KycVerification = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Enhanced Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-64 h-64 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-br from-indigo-200/30 to-blue-200/30 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
          <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-gradient-to-br from-purple-200/20 to-pink-200/20 rounded-full blur-2xl animate-pulse" style={{animationDelay: '4s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-6">
                <div className="inline-flex items-center space-x-2 bg-blue-100 rounded-full px-4 py-2 border border-blue-200">
                  <Shield className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-700">Secure Identity Solutions</span>
                </div>

                <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  <span className="text-blue-600">KYC</span> And<br />
                  Identity Verification
                </h1>
                
                <p className="text-lg text-gray-600 leading-relaxed">
                  Security and trust are two of the most important aspects people look for in 
                  the modern world. SovaPay Technologies offers innovative solutions in KYC and 
                  identity verification, which are critical in enhancing trust, managing risks, and 
                  addressing compliance issues. Our advanced verification systems ensure seamless 
                  onboarding while maintaining the highest security standards.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105 shadow-lg">
                  <span>Get Started</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
                
                <button className="border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-4 rounded-full font-semibold transition-all duration-300">
                  Learn More
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="flex items-center space-x-8 pt-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">Instant Verification</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">99.9% Accuracy</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">Secure & Compliant</span>
                </div>
              </div>
            </div>

            {/* Enhanced Right Content - Premium KYC Animation */}
            <div className="relative">
              <div className="relative w-full h-[500px] perspective-1000">
                {/* Enhanced Background Gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 to-purple-100/50 rounded-3xl overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-200/20 via-transparent to-purple-200/20"></div>
                </div>

                {/* Main 3D Scene Container */}
                <div className="absolute inset-0 transform-gpu preserve-3d" style={{transform: 'rotateX(10deg) rotateY(-10deg) translateZ(0)'}}>
                  
                  {/* Enhanced Person with Documents */}
                  <div className="absolute left-16 top-1/2 transform -translate-y-1/2">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-15deg) rotateY(20deg)'}}>
                      {/* Person Shadow */}
                      <div className="absolute top-12 left-12 w-20 h-32 bg-black/15 rounded-t-full blur-lg transform skew-x-6 skew-y-6"></div>
                      
                      {/* Person Body */}
                      <div className="w-20 h-32 bg-gradient-to-b from-yellow-400 to-orange-600 rounded-t-full relative overflow-hidden shadow-2xl">
                        {/* Person Highlight */}
                        <div className="absolute top-2 left-2 w-6 h-8 bg-white/30 rounded blur-sm"></div>
                        
                        {/* Head */}
                        <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-yellow-200 rounded-full shadow-lg border-2 border-yellow-100"></div>
                        
                        {/* Document in Hand */}
                        <div className="absolute top-4 right-2">
                          <div className="w-6 h-8 bg-gradient-to-b from-white to-gray-100 rounded shadow-lg border border-gray-300">
                            <div className="p-0.5">
                              <div className="h-6 bg-gradient-to-b from-blue-100 to-blue-200 rounded relative overflow-hidden">
                                {/* Document Content */}
                                <div className="absolute top-1 left-1 right-1">
                                  <div className="text-center mb-1">
                                    <div className="text-blue-600 text-xs font-bold">ID</div>
                                  </div>
                                  
                                  {/* Document Lines */}
                                  <div className="space-y-0.5">
                                    <div className="h-0.5 bg-blue-400 rounded"></div>
                                    <div className="h-0.5 bg-blue-300 rounded w-3/4"></div>
                                    <div className="h-0.5 bg-blue-200 rounded w-1/2"></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {/* Verification Badge */}
                        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2">
                          <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
                            <CheckCircle className="w-2 h-2 text-white" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Verification Dashboard */}
                  <div className="absolute right-12 top-16">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-20deg) rotateY(-30deg)'}}>
                      {/* Dashboard Shadow */}
                      <div className="absolute top-12 left-12 w-40 h-32 bg-black/15 rounded-xl blur-xl transform skew-x-12 skew-y-6"></div>
                      
                      {/* Main Dashboard */}
                      <div className="w-40 h-32 bg-gradient-to-b from-gray-100 to-gray-200 rounded-xl shadow-2xl border border-gray-300 relative overflow-hidden">
                        {/* Dashboard Highlight */}
                        <div className="absolute top-1 left-2 w-10 h-6 bg-white/60 rounded blur-sm"></div>
                        
                        {/* Right Side */}
                        <div className="absolute top-0 -right-4 w-4 h-32 bg-gradient-to-b from-gray-200 to-gray-400 transform skew-y-12 shadow-lg"></div>
                        
                        {/* Top Side */}
                        <div className="absolute -top-3 left-0 w-40 h-3 bg-gradient-to-r from-gray-50 to-gray-200 transform skew-x-12 shadow-lg"></div>
                        
                        {/* Screen Content */}
                        <div className="p-3">
                          {/* Header */}
                          <div className="h-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded mb-2 flex items-center justify-center">
                            <span className="text-white text-xs font-bold">KYC DASHBOARD</span>
                          </div>
                          
                          {/* Verification Status */}
                          <div className="grid grid-cols-2 gap-1 mb-2">
                            <div className="h-4 bg-gradient-to-r from-green-400 to-green-600 rounded flex items-center justify-center">
                              <UserCheck className="w-2 h-2 text-white" />
                            </div>
                            <div className="h-4 bg-gradient-to-r from-blue-400 to-blue-600 rounded flex items-center justify-center">
                              <FileCheck className="w-2 h-2 text-white" />
                            </div>
                            <div className="h-4 bg-gradient-to-r from-purple-400 to-purple-600 rounded flex items-center justify-center">
                              <Shield className="w-2 h-2 text-white" />
                            </div>
                            <div className="h-4 bg-gradient-to-r from-orange-400 to-orange-600 rounded flex items-center justify-center">
                              <Eye className="w-2 h-2 text-white" />
                            </div>
                          </div>
                          
                          {/* Status Indicator */}
                          <div className="h-3 bg-gradient-to-r from-green-400 to-green-600 rounded flex items-center justify-center">
                            <span className="text-white text-xs font-bold">VERIFIED</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Floating Document Icons */}
                  <div className="absolute top-20 right-20 animate-float-slow">
                    <div className="relative transform rotate-12">
                      <div className="w-12 h-16 bg-gradient-to-b from-blue-400 to-blue-600 rounded shadow-xl border border-blue-300 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-2 h-2 bg-blue-200 rounded-full"></div>
                        <div className="absolute bottom-1 right-1">
                          <Fingerprint className="w-3 h-3 text-white" />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-white text-xs font-bold">ID</div>
                      </div>
                    </div>
                  </div>

                  <div className="absolute bottom-24 left-8 animate-float-medium" style={{animationDelay: '1s'}}>
                    <div className="relative transform -rotate-12">
                      <div className="w-12 h-16 bg-gradient-to-b from-green-400 to-green-600 rounded shadow-xl border border-green-300 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-2 h-2 bg-green-200 rounded-full"></div>
                        <div className="absolute bottom-1 right-1">
                          <FileCheck className="w-3 h-3 text-white" />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-white text-xs font-bold">DOC</div>
                      </div>
                    </div>
                  </div>

                  <div className="absolute top-32 left-24 animate-float-fast" style={{animationDelay: '2s'}}>
                    <div className="relative transform rotate-6">
                      <div className="w-12 h-16 bg-gradient-to-b from-purple-400 to-purple-600 rounded shadow-xl border border-purple-300 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-2 h-2 bg-purple-200 rounded-full"></div>
                        <div className="absolute bottom-1 right-1">
                          <Lock className="w-3 h-3 text-white" />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-white text-xs font-bold">SEC</div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Security Shield */}
                  <div className="absolute bottom-16 right-24 animate-float-slow" style={{animationDelay: '0.5s'}}>
                    <div className="relative">
                      <div className="w-16 h-18 bg-gradient-to-b from-blue-500 to-blue-700 rounded-t-full rounded-b-lg shadow-xl border-2 border-blue-300 flex items-center justify-center">
                        <Shield className="w-8 h-8 text-white" />
                      </div>
                      <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-blue-300 rounded-full animate-ping"></div>
                    </div>
                  </div>

                  {/* Enhanced Golden Coins */}
                  <div className="absolute top-40 right-32 animate-coin-bounce">
                    <div className="relative">
                      <div className="w-8 h-8 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-xs">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-8 h-2 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  <div className="absolute bottom-32 left-32 animate-coin-bounce" style={{animationDelay: '0.5s'}}>
                    <div className="relative">
                      <div className="w-6 h-6 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-xs">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-6 h-1.5 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  {/* Network Connection Lines */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-80 h-80 border border-dashed border-blue-300/30 rounded-full animate-spin opacity-40" style={{animationDuration: '30s'}}></div>
                    <div className="absolute w-64 h-64 border border-dashed border-purple-300/25 rounded-full animate-spin opacity-35" style={{animationDuration: '25s', animationDirection: 'reverse'}}></div>
                  </div>

                  {/* Floating Particles */}
                  <div className="absolute top-16 left-40 w-2 h-2 bg-blue-400 rounded-full animate-ping"></div>
                  <div className="absolute bottom-20 left-24 w-1.5 h-1.5 bg-purple-400 rounded-full animate-ping" style={{animationDelay: '1s'}}></div>
                  <div className="absolute top-40 right-32 w-1 h-1 bg-green-400 rounded-full animate-ping" style={{animationDelay: '2s'}}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Key Services Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-600/80 via-purple-600/80 to-indigo-600/80"></div>
          <div className="absolute top-20 left-20 w-32 h-32 bg-white/10 rounded-full blur-2xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-40 h-40 bg-white/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Key Services
            </h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Comprehensive identity verification solutions for modern businesses
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Enhanced Service Cards */}
            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Secure KYC Solutions</h3>
              <p className="text-gray-600 leading-relaxed">
                Conduct KYC quickly and effectively using our advanced solutions. We streamline the procedure of 
                obtaining the documents required to confirm the clients' address, financial standing, and 
                identity, as well as compliance with regulatory requirements.
              </p>
            </div>

            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <UserCheck className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Advanced Identity Verification</h3>
              <p className="text-gray-600 leading-relaxed">
                Use our biometric authentication, document verification and data analysis services to 
                prevent fraud and build trust. All applications are created with the user in mind and can be scaled 
                as your company evolves.
              </p>
            </div>

            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <FileCheck className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Compliance and Security</h3>
              <p className="text-gray-600 leading-relaxed">
                SovaPay acknowledges the importance of users' data and the security of the information that is 
                inputted. We use the highest level of encryption and follow the highest compliance standards to 
                protect your business information.
              </p>
            </div>
          </div>

          <div className="text-center mt-12">
            <button className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg">
              Contact Us
            </button>
          </div>
        </div>
      </section>

      {/* Enhanced Why Choose Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <h2 className="text-4xl font-bold text-gray-900">
                Why Choose <span className="text-blue-600">SovaPay</span>?
              </h2>

              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Fast Onboarding</h3>
                    <p className="text-gray-600 leading-relaxed">
                      Automate manual tasks and onboard customers as soon as possible with our 
                      streamlined verification processes.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Cutting-Edge Technology</h3>
                    <p className="text-gray-600 leading-relaxed">
                      Stand out from the competition with our modern and time-saving 
                      verification solutions powered by AI and machine learning.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Settings className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">User-Centric Design</h3>
                    <p className="text-gray-600 leading-relaxed">
                      Perfect example of flexible workflows and seamless integration 
                      that enhances user experience while maintaining security.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Content - Enhanced Verification Animation */}
            <div className="relative">
              <div className="relative w-full h-96 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-3xl p-8 overflow-hidden">
                {/* Enhanced Verification Scene */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  {/* Person with Verification */}
                  <div className="w-20 h-24 bg-gradient-to-b from-blue-500 to-blue-700 rounded-t-full relative animate-float-slow">
                    {/* Head */}
                    <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-yellow-200 rounded-full shadow-lg border-2 border-yellow-100"></div>
                    
                    {/* Verification Badge */}
                    <div className="absolute top-2 left-1/2 transform -translate-x-1/2">
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
                        <CheckCircle className="w-5 h-5 text-white" />
                      </div>
                    </div>
                    
                    {/* Document */}
                    <div className="absolute top-8 right-0 w-6 h-8 bg-white rounded shadow-lg border border-gray-300">
                      <div className="p-1">
                        <div className="h-1 bg-blue-500 rounded mb-1"></div>
                        <div className="h-1 bg-blue-400 rounded w-3/4 mb-1"></div>
                        <div className="h-1 bg-blue-300 rounded w-1/2"></div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Floating Verification Icons */}
                <div className="absolute top-8 left-8 w-8 h-8 bg-green-500 rounded-full animate-bounce flex items-center justify-center">
                  <UserCheck className="w-4 h-4 text-white" />
                </div>
                
                <div className="absolute bottom-8 right-8 w-8 h-8 bg-blue-500 rounded-full animate-pulse flex items-center justify-center">
                  <Shield className="w-4 h-4 text-white" />
                </div>

                <div className="absolute top-16 right-16 w-6 h-6 bg-purple-500 rounded-full animate-ping flex items-center justify-center">
                  <FileCheck className="w-3 h-3 text-white" />
                </div>

                {/* Verification Progress */}
                <div className="absolute bottom-12 left-8 right-8">
                  <div className="bg-white/80 rounded-lg p-3 shadow-lg">
                    <div className="text-xs font-bold text-gray-700 mb-2">Verification Progress</div>
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <div className="text-xs text-gray-600">Identity Verified</div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <div className="text-xs text-gray-600">Documents Approved</div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                        <div className="text-xs text-gray-600">Processing...</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gray-900 via-blue-900 to-indigo-900 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-gray-900/90 via-blue-900/90 to-indigo-900/90"></div>
          <div className="absolute top-20 left-20 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 text-center relative z-10">
          <div className="max-w-4xl mx-auto space-y-8">
            <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
              Choose SovaPay Technologies for the most efficient and secure KYC and identity verification services that will boost your business.
            </h2>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg">
                Contact Us
              </button>
              <button className="border-2 border-white/30 hover:border-white/50 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 hover:bg-white/10 backdrop-blur-sm">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      <style jsx>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .preserve-3d {
          transform-style: preserve-3d;
        }
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          33% { transform: translateY(-8px) translateX(4px) rotateZ(2deg); }
          66% { transform: translateY(4px) translateX(-2px) rotateZ(-1deg); }
        }
        @keyframes float-medium {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          50% { transform: translateY(-12px) translateX(6px) rotateZ(3deg); }
        }
        @keyframes float-fast {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          25% { transform: translateY(-6px) translateX(3px) rotateZ(1deg); }
          75% { transform: translateY(6px) translateX(-3px) rotateZ(-2deg); }
        }
        @keyframes coin-bounce {
          0%, 100% { transform: translateY(0px) rotateY(0deg); }
          25% { transform: translateY(-8px) rotateY(90deg); }
          50% { transform: translateY(-4px) rotateY(180deg); }
          75% { transform: translateY(-8px) rotateY(270deg); }
        }
        .animate-float-slow {
          animation: float-slow 6s ease-in-out infinite;
        }
        .animate-float-medium {
          animation: float-medium 4s ease-in-out infinite;
        }
        .animate-float-fast {
          animation: float-fast 3s ease-in-out infinite;
        }
        .animate-coin-bounce {
          animation: coin-bounce 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default KycVerification;