import React from 'react';
import { 
  CreditCard, 
  Shield, 
  Users, 
  CheckCircle,
  ArrowRight,
  Banknote,
  TrendingUp,
  Smartphone,
  Building2,
  MapPin,
  Clock,
  Star,
  Zap,
  DollarSign
} from 'lucide-react';

const MicroAtmServices = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Enhanced Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-64 h-64 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-br from-indigo-200/30 to-blue-200/30 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
          <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-gradient-to-br from-purple-200/20 to-pink-200/20 rounded-full blur-2xl animate-pulse" style={{animationDelay: '4s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-2 bg-blue-100 rounded-full px-4 py-2 border border-blue-200 mb-6">
              <CreditCard className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-700">Portable Banking Solution</span>
            </div>

            <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              <span className="text-blue-600">Micro ATM</span>
            </h1>
            <p className="text-2xl text-gray-700 mb-4">Bring Banking to Your Customers</p>
            
            {/* Enhanced Micro ATM Animation */}
            <div className="relative w-full max-w-2xl mx-auto h-80 mb-8">
              <div className="relative w-full h-full perspective-1000">
                {/* Background Gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 to-purple-100/50 rounded-3xl overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-200/20 via-transparent to-purple-200/20"></div>
                </div>

                {/* Main 3D Scene Container */}
                <div className="absolute inset-0 transform-gpu preserve-3d" style={{transform: 'rotateX(10deg) rotateY(-5deg) translateZ(0)'}}>
                  
                  {/* Enhanced Micro ATM Device */}
                  <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-20deg) rotateY(-15deg)'}}>
                      {/* Device Shadow */}
                      <div className="absolute top-12 left-12 w-32 h-48 bg-black/15 rounded-xl blur-xl transform skew-x-12 skew-y-6"></div>
                      
                      {/* Main Device Body */}
                      <div className="w-32 h-48 bg-gradient-to-b from-blue-600 via-blue-700 to-blue-900 rounded-xl shadow-2xl border border-blue-500 relative overflow-hidden">
                        {/* Device Highlight */}
                        <div className="absolute top-2 left-2 w-8 h-12 bg-white/20 rounded blur-sm"></div>
                        
                        {/* Right Side Panel */}
                        <div className="absolute top-0 -right-4 w-4 h-48 bg-gradient-to-b from-blue-700 to-blue-900 transform skew-y-12 shadow-lg"></div>
                        
                        {/* Top Panel */}
                        <div className="absolute -top-3 left-0 w-32 h-3 bg-gradient-to-r from-blue-500 to-blue-700 transform skew-x-12 shadow-lg"></div>
                        
                        {/* Screen */}
                        <div className="p-3 pt-4">
                          <div className="h-20 bg-gradient-to-b from-gray-100 to-gray-300 rounded-lg shadow-inner border border-gray-200 relative overflow-hidden">
                            {/* Screen Content */}
                            <div className="absolute top-2 left-2 right-2">
                              <div className="text-center mb-2">
                                <div className="text-blue-600 text-xs font-bold">Micro ATM</div>
                              </div>
                              
                              {/* Transaction Display */}
                              <div className="space-y-1">
                                <div className="h-1 bg-blue-500 rounded"></div>
                                <div className="h-1 bg-blue-400 rounded w-3/4"></div>
                                <div className="h-1 bg-blue-300 rounded w-1/2"></div>
                              </div>
                              
                              {/* Amount Display */}
                              <div className="mt-2 text-center">
                                <div className="text-green-600 text-xs font-bold">₹2,500</div>
                              </div>
                            </div>
                          </div>
                          
                          {/* Keypad */}
                          <div className="mt-2 grid grid-cols-3 gap-1">
                            {[...Array(9)].map((_, i) => (
                              <div key={i} className="w-3 h-3 bg-gradient-to-b from-gray-300 to-gray-500 rounded shadow-sm"></div>
                            ))}
                          </div>
                          
                          {/* Card Slot */}
                          <div className="mt-2 h-2 bg-gradient-to-r from-gray-800 to-black rounded shadow-inner"></div>
                        </div>
                        
                        {/* Status LED */}
                        <div className="absolute top-2 right-2 w-2 h-2 bg-green-400 rounded-full animate-pulse shadow-lg"></div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Person with Mobile */}
                  <div className="absolute right-16 top-1/2 transform -translate-y-1/2">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-15deg) rotateY(20deg)'}}>
                      {/* Person Shadow */}
                      <div className="absolute top-12 left-12 w-20 h-32 bg-black/15 rounded-t-full blur-lg transform skew-x-6 skew-y-6"></div>
                      
                      {/* Person Body */}
                      <div className="w-20 h-32 bg-gradient-to-b from-green-400 to-green-600 rounded-t-full relative overflow-hidden shadow-2xl">
                        {/* Person Highlight */}
                        <div className="absolute top-2 left-2 w-6 h-8 bg-white/30 rounded blur-sm"></div>
                        
                        {/* Head */}
                        <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-yellow-200 rounded-full shadow-lg border-2 border-yellow-100"></div>
                        
                        {/* Mobile in Hand */}
                        <div className="absolute top-4 right-2">
                          <div className="w-6 h-10 bg-gradient-to-b from-gray-800 to-gray-900 rounded shadow-lg border border-gray-700">
                            <div className="p-0.5 pt-1">
                              <div className="h-7 bg-gradient-to-b from-blue-500 to-blue-700 rounded relative overflow-hidden">
                                {/* Banking App Interface */}
                                <div className="absolute top-1 left-1 right-1">
                                  <div className="text-center mb-1">
                                    <div className="text-white text-xs font-bold">BANK</div>
                                  </div>
                                  
                                  {/* Balance Display */}
                                  <div className="bg-white/20 rounded p-0.5 mb-1 text-center">
                                    <div className="text-white text-xs">₹15,250</div>
                                  </div>
                                  
                                  {/* Transaction Button */}
                                  <div className="bg-green-500 rounded p-0.5 text-center animate-pulse">
                                    <div className="text-white text-xs font-bold">OK</div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {/* Success Indicator */}
                        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2">
                          <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
                            <CheckCircle className="w-2 h-2 text-white" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Security Shield */}
                  <div className="absolute top-16 right-24 animate-float-slow">
                    <div className="relative">
                      <div className="w-12 h-14 bg-gradient-to-b from-blue-500 to-blue-700 rounded-t-full rounded-b-lg shadow-xl border-2 border-blue-300 flex items-center justify-center">
                        <Shield className="w-6 h-6 text-white" />
                      </div>
                      <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-3 h-3 bg-blue-300 rounded-full animate-ping"></div>
                    </div>
                  </div>

                  {/* Enhanced Golden Coins */}
                  <div className="absolute bottom-16 left-16 animate-coin-bounce">
                    <div className="relative">
                      <div className="w-10 h-10 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-sm">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-10 h-2 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  <div className="absolute top-32 left-24 animate-coin-bounce" style={{animationDelay: '0.5s'}}>
                    <div className="relative">
                      <div className="w-8 h-8 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-xs">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-8 h-1.5 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  <div className="absolute bottom-24 right-32 animate-coin-bounce" style={{animationDelay: '1s'}}>
                    <div className="relative">
                      <div className="w-6 h-6 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-xs">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-6 h-1.5 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  {/* Floating Particles */}
                  <div className="absolute top-20 left-32 w-2 h-2 bg-blue-400 rounded-full animate-ping"></div>
                  <div className="absolute bottom-32 left-40 w-1.5 h-1.5 bg-purple-400 rounded-full animate-ping" style={{animationDelay: '1s'}}></div>
                  <div className="absolute top-40 right-40 w-1 h-1 bg-green-400 rounded-full animate-ping" style={{animationDelay: '2s'}}></div>
                </div>
              </div>
            </div>

            <p className="text-lg text-gray-600 leading-relaxed max-w-3xl mx-auto mb-8">
              Micro ATM service provided by SovaPay allows merchants to provide all the basic 
              functions of an ATM and thus increase financial inclusion. It is cost effective for the 
              merchants and customers, especially in rural areas making it a suitable solution.
            </p>

            <button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105 shadow-lg mx-auto">
              <span>Get Started</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Enhanced SovaPay's Micro ATM Services Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <h2 className="text-4xl font-bold text-gray-900">
                SovaPay's <span className="text-blue-600">Micro ATM</span> Services
              </h2>
              
              <p className="text-lg text-gray-600 leading-relaxed">
                Micro ATM (mATM) is a portable handheld device that allows users to 
                withdraw cash and check their bank account balances, just like a 
                traditional ATM. SovaPay Micro ATMs are especially useful in areas where 
                bank ATMs are scarce, making cash withdrawals more accessible and 
                convenient for customers, particularly in rural and Tier 2-3 areas. By 
                leveraging our mATM services, countless Indian retailers are 
                experiencing significant growth in both their income and business.
              </p>
            </div>

            {/* Right Content - Enhanced mATM Animation */}
            <div className="relative">
              <div className="relative w-full h-96 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-3xl p-8 overflow-hidden">
                {/* Enhanced ATM Device */}
                <div className="absolute right-12 top-1/2 transform -translate-y-1/2">
                  <div className="w-20 h-32 bg-gradient-to-b from-blue-600 to-blue-800 rounded-lg shadow-xl relative">
                    {/* ATM Screen */}
                    <div className="p-2 pt-3">
                      <div className="h-16 bg-gradient-to-b from-gray-100 to-gray-300 rounded shadow-inner relative">
                        <div className="absolute top-1 left-1 right-1">
                          <div className="text-center mb-1">
                            <div className="text-blue-600 text-xs font-bold">ATM</div>
                          </div>
                          <div className="space-y-0.5">
                            <div className="h-0.5 bg-blue-500 rounded"></div>
                            <div className="h-0.5 bg-blue-400 rounded w-3/4"></div>
                            <div className="h-0.5 bg-blue-300 rounded w-1/2"></div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Keypad */}
                      <div className="mt-1 grid grid-cols-3 gap-0.5">
                        {[...Array(9)].map((_, i) => (
                          <div key={i} className="w-2 h-2 bg-gray-400 rounded"></div>
                        ))}
                      </div>
                    </div>
                    
                    {/* Status Light */}
                    <div className="absolute top-1 right-1 w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></div>
                  </div>
                </div>

                {/* Person Using ATM */}
                <div className="absolute left-12 top-1/2 transform -translate-y-1/2">
                  <div className="w-16 h-20 bg-gradient-to-b from-orange-400 to-orange-600 rounded-t-full relative">
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-yellow-200 rounded-full"></div>
                    <div className="absolute top-2 right-0 w-4 h-6 bg-gray-800 rounded"></div>
                  </div>
                </div>

                {/* Money Flow */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-24 h-1 bg-gradient-to-r from-green-400 to-blue-500 rounded-full relative">
                    <div className="absolute top-1/2 transform -translate-y-1/2 w-3 h-3 bg-yellow-400 rounded-full animate-money-flow"></div>
                  </div>
                </div>

                {/* Floating Elements */}
                <div className="absolute top-8 left-8 w-6 h-6 bg-green-400 rounded-full animate-bounce flex items-center justify-center">
                  <Banknote className="w-3 h-3 text-white" />
                </div>
                <div className="absolute bottom-8 right-8 w-4 h-4 bg-blue-400 rounded-full animate-pulse"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Benefits Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Benefits for Merchants */}
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-6">
                <Building2 className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Benefits for Merchants</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Low setup costs</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Attractive commissions on each transaction</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Increased foot traffic and business growth</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Simple installation and operation</span>
                </li>
              </ul>
            </div>

            {/* Why Choose SovaPay's Micro ATM */}
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mb-6">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Why Choose SovaPay's Micro ATM?</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Portable device for cash withdrawals and balance checks</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Ideal for areas with limited ATM access</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Boosts income for Indian retailers</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Serves customers in rural and Tier 2-3 areas</span>
                </li>
              </ul>
            </div>

            {/* Advantages for Customers */}
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Advantages for Customers</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Convenient access to cash withdrawals</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Easy balance inquiries</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Reduced travel time to find ATMs</span>
                </li>
                <li className="flex items-start space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>Available at local, trusted merchants</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-600/80 via-purple-600/80 to-indigo-600/80"></div>
          <div className="absolute top-20 left-20 w-32 h-32 bg-white/10 rounded-full blur-2xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-40 h-40 bg-white/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 text-center relative z-10">
          <div className="max-w-4xl mx-auto space-y-8">
            <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
              Join SovaPay's Micro ATM Network
            </h2>
            <p className="text-xl text-blue-100 leading-relaxed">
              Grow your enterprise and offer basic banking products to your people. Get in touch with us to find out how you can become a SovaPay-affiliated merchant and begin offering Micro ATM services.
            </p>
            
            <button className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg">
              Contact Us
            </button>
          </div>
        </div>
      </section>

      <style jsx>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .preserve-3d {
          transform-style: preserve-3d;
        }
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          33% { transform: translateY(-8px) translateX(4px) rotateZ(2deg); }
          66% { transform: translateY(4px) translateX(-2px) rotateZ(-1deg); }
        }
        @keyframes money-flow {
          0% { left: 0; }
          100% { left: calc(100% - 12px); }
        }
        @keyframes coin-bounce {
          0%, 100% { transform: translateY(0px) rotateY(0deg); }
          25% { transform: translateY(-8px) rotateY(90deg); }
          50% { transform: translateY(-4px) rotateY(180deg); }
          75% { transform: translateY(-8px) rotateY(270deg); }
        }
        .animate-float-slow {
          animation: float-slow 6s ease-in-out infinite;
        }
        .animate-money-flow {
          animation: money-flow 3s ease-in-out infinite;
        }
        .animate-coin-bounce {
          animation: coin-bounce 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default MicroAtmServices;