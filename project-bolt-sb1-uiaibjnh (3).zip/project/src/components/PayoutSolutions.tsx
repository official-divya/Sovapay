import React from 'react';
import { 
  CreditCard, 
  Shield, 
  TrendingUp, 
  CheckCircle,
  ArrowRight,
  Users,
  Building2,
  Smartphone,
  Globe,
  Zap,
  DollarSign,
  Star,
  Award,
  Target,
  BarChart3,
  Clock,
  RefreshCw,
  Monitor,
  Database,
  Settings,
  Banknote,
  ShoppingCart,
  UserCheck
} from 'lucide-react';

const PayoutSolutions = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Enhanced Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-64 h-64 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-br from-indigo-200/30 to-blue-200/30 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
          <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-gradient-to-br from-purple-200/20 to-pink-200/20 rounded-full blur-2xl animate-pulse" style={{animationDelay: '4s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-6">
                <div className="inline-flex items-center space-x-2 bg-blue-100 rounded-full px-4 py-2 border border-blue-200">
                  <CreditCard className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-700">Streamlined Financial Disbursements</span>
                </div>

                <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  <span className="text-blue-600">Payout</span> Solutions
                </h1>
                
                <p className="text-lg text-gray-600 leading-relaxed">
                  In the current world economy, the payment system is a vital component of the 
                  business environment. SovaPay Technologies has efficient payout solutions for 
                  single and multiple transactions. It deals with customer payments and 
                  vendor/employee disbursements, thus easing your company's financial 
                  management.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105 shadow-lg">
                  <span>Get Started</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
                
                <button className="border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-4 rounded-full font-semibold transition-all duration-300">
                  Learn More
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="flex items-center space-x-8 pt-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">Instant Payouts</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">Secure Processing</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">24/7 Support</span>
                </div>
              </div>
            </div>

            {/* Enhanced Right Content - Premium Payout Animation */}
            <div className="relative">
              <div className="relative w-full h-[500px] perspective-1000">
                {/* Enhanced Background Gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 to-purple-100/50 rounded-3xl overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-200/20 via-transparent to-purple-200/20"></div>
                </div>

                {/* Main 3D Scene Container */}
                <div className="absolute inset-0 transform-gpu preserve-3d" style={{transform: 'rotateX(10deg) rotateY(-10deg) translateZ(0)'}}>
                  
                  {/* Enhanced Person with Mobile */}
                  <div className="absolute left-16 top-1/2 transform -translate-y-1/2">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-15deg) rotateY(20deg)'}}>
                      {/* Person Shadow */}
                      <div className="absolute top-12 left-12 w-20 h-32 bg-black/15 rounded-t-full blur-lg transform skew-x-6 skew-y-6"></div>
                      
                      {/* Person Body */}
                      <div className="w-20 h-32 bg-gradient-to-b from-blue-400 to-blue-600 rounded-t-full relative overflow-hidden shadow-2xl">
                        {/* Person Highlight */}
                        <div className="absolute top-2 left-2 w-6 h-8 bg-white/30 rounded blur-sm"></div>
                        
                        {/* Head */}
                        <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-yellow-200 rounded-full shadow-lg border-2 border-yellow-100"></div>
                        
                        {/* Mobile in Hand */}
                        <div className="absolute top-4 right-2">
                          <div className="w-6 h-10 bg-gradient-to-b from-gray-800 to-gray-900 rounded shadow-lg border border-gray-700">
                            <div className="p-0.5 pt-1">
                              <div className="h-7 bg-gradient-to-b from-blue-500 to-blue-700 rounded relative overflow-hidden">
                                {/* Payout Interface */}
                                <div className="absolute top-1 left-1 right-1">
                                  <div className="text-center mb-1">
                                    <div className="text-white text-xs font-bold">PAYOUT</div>
                                  </div>
                                  
                                  {/* Amount Display */}
                                  <div className="bg-white/20 rounded p-0.5 mb-1 text-center">
                                    <div className="text-white text-xs">₹25,000</div>
                                  </div>
                                  
                                  {/* Send Button */}
                                  <div className="bg-green-500 rounded p-0.5 text-center animate-pulse">
                                    <div className="text-white text-xs font-bold">SEND</div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {/* Success Indicator */}
                        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2">
                          <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
                            <CheckCircle className="w-2 h-2 text-white" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Dual Mobile Phones */}
                  <div className="absolute right-12 top-16">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-20deg) rotateY(-30deg)'}}>
                      {/* Phone 1 Shadow */}
                      <div className="absolute top-8 left-8 w-20 h-36 bg-black/15 rounded-2xl blur-lg transform skew-x-6 skew-y-6"></div>
                      
                      {/* Phone 1 */}
                      <div className="w-20 h-36 bg-gradient-to-b from-slate-800 to-slate-900 rounded-2xl shadow-2xl border-2 border-slate-700 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-4 h-8 bg-white/10 rounded-lg blur-sm"></div>
                        <div className="absolute top-0 -right-2 w-2 h-36 bg-gradient-to-b from-slate-900 to-black transform skew-y-6 shadow-lg"></div>
                        
                        <div className="p-2 pt-3">
                          <div className="h-28 bg-gradient-to-br from-purple-600 via-purple-700 to-indigo-800 rounded-xl relative overflow-hidden shadow-inner border border-purple-500">
                            <div className="absolute inset-0 bg-gradient-to-t from-transparent to-white/5"></div>
                            
                            {/* Payout Dashboard */}
                            <div className="absolute top-2 left-2 right-2">
                              <div className="text-center mb-2">
                                <div className="text-white text-xs font-bold">PAYOUTS</div>
                              </div>
                              
                              {/* Transaction List */}
                              <div className="space-y-1 mb-2">
                                <div className="h-1 bg-green-400 rounded animate-pulse"></div>
                                <div className="h-1 bg-blue-400 rounded animate-pulse" style={{animationDelay: '0.3s'}}></div>
                                <div className="h-1 bg-yellow-400 rounded animate-pulse" style={{animationDelay: '0.6s'}}></div>
                              </div>
                              
                              {/* Status */}
                              <div className="bg-green-500 rounded p-1 text-center">
                                <div className="text-white text-xs font-bold">PROCESSED</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Phone 2 - Offset */}
                  <div className="absolute right-8 bottom-16">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-15deg) rotateY(-25deg)'}}>
                      <div className="absolute top-6 left-6 w-18 h-32 bg-black/15 rounded-2xl blur-lg transform skew-x-6 skew-y-6"></div>
                      
                      <div className="w-18 h-32 bg-gradient-to-b from-slate-800 to-slate-900 rounded-2xl shadow-2xl border-2 border-slate-700 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-3 h-6 bg-white/10 rounded blur-sm"></div>
                        <div className="absolute top-0 -right-1.5 w-1.5 h-32 bg-gradient-to-b from-slate-900 to-black transform skew-y-6 shadow-lg"></div>
                        
                        <div className="p-1.5 pt-2">
                          <div className="h-24 bg-gradient-to-br from-green-600 via-green-700 to-emerald-800 rounded-lg relative overflow-hidden shadow-inner border border-green-500">
                            <div className="absolute inset-0 bg-gradient-to-t from-transparent to-white/5"></div>
                            
                            {/* Received Interface */}
                            <div className="absolute top-1.5 left-1.5 right-1.5">
                              <div className="text-center mb-1.5">
                                <div className="text-white text-xs font-bold">RECEIVED</div>
                              </div>
                              
                              {/* Amount */}
                              <div className="bg-white/20 rounded p-0.5 mb-1.5 text-center">
                                <div className="text-white text-xs">₹25,000</div>
                              </div>
                              
                              {/* Success */}
                              <div className="bg-green-400 rounded p-0.5 text-center">
                                <div className="text-white text-xs font-bold">SUCCESS</div>
                              </div>
                              
                              {/* Checkmark */}
                              <div className="flex justify-center mt-1">
                                <div className="w-3 h-3 bg-green-400 rounded-full flex items-center justify-center animate-pulse">
                                  <CheckCircle className="w-1.5 h-1.5 text-white" />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Money Flow Animation */}
                  <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="relative w-40 h-2">
                      <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-green-500 rounded-full opacity-30"></div>
                      
                      {/* Animated Money Flow */}
                      <div className="absolute top-1/2 transform -translate-y-1/2 w-4 h-4 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full shadow-lg animate-money-flow">
                        <div className="absolute inset-0 bg-yellow-300 rounded-full animate-ping"></div>
                        <div className="absolute inset-1 bg-white rounded-full flex items-center justify-center">
                          <span className="text-xs font-bold text-yellow-600">₹</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Floating Currency Notes */}
                  <div className="absolute top-20 left-20 animate-float-slow">
                    <div className="relative transform rotate-12">
                      <div className="w-16 h-10 bg-gradient-to-r from-green-500 to-green-700 rounded shadow-xl border border-green-400 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-3 h-3 bg-green-300 rounded-full"></div>
                        <div className="absolute bottom-1 right-1 text-white text-xs font-bold">₹</div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                      </div>
                    </div>
                  </div>

                  <div className="absolute bottom-24 right-8 animate-float-medium" style={{animationDelay: '1s'}}>
                    <div className="relative transform -rotate-12">
                      <div className="w-16 h-10 bg-gradient-to-r from-blue-500 to-blue-700 rounded shadow-xl border border-blue-400 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-3 h-3 bg-blue-300 rounded-full"></div>
                        <div className="absolute bottom-1 right-1 text-white text-xs font-bold">₹</div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Golden Coins */}
                  <div className="absolute top-32 right-20 animate-coin-bounce">
                    <div className="relative">
                      <div className="w-8 h-8 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-xs">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-8 h-2 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  <div className="absolute bottom-32 left-32 animate-coin-bounce" style={{animationDelay: '0.5s'}}>
                    <div className="relative">
                      <div className="w-6 h-6 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-xs">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-6 h-1.5 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  {/* Network Connection Lines */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-80 h-80 border border-dashed border-blue-300/30 rounded-full animate-spin opacity-40" style={{animationDuration: '30s'}}></div>
                    <div className="absolute w-64 h-64 border border-dashed border-purple-300/25 rounded-full animate-spin opacity-35" style={{animationDuration: '25s', animationDirection: 'reverse'}}></div>
                  </div>

                  {/* Floating Particles */}
                  <div className="absolute top-16 left-40 w-2 h-2 bg-blue-400 rounded-full animate-ping"></div>
                  <div className="absolute bottom-20 left-24 w-1.5 h-1.5 bg-purple-400 rounded-full animate-ping" style={{animationDelay: '1s'}}></div>
                  <div className="absolute top-40 right-32 w-1 h-1 bg-green-400 rounded-full animate-ping" style={{animationDelay: '2s'}}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Why Choose Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-600/80 via-purple-600/80 to-indigo-600/80"></div>
          <div className="absolute top-20 left-20 w-32 h-32 bg-white/10 rounded-full blur-2xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-40 h-40 bg-white/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Why Choose SovaPay's Payout Solutions?
            </h2>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Experience seamless, secure, and efficient payout processing
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Enhanced Benefit Cards */}
            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Seamless API Integrations</h3>
              <p className="text-gray-600 leading-relaxed">
                Simplify your payment processing with ease. Scale your operations without added 
                complexity. Our robust APIs ensure smooth integration with your existing systems.
              </p>
            </div>

            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Monitor className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Real-Time Monitoring</h3>
              <p className="text-gray-600 leading-relaxed">
                All payments are monitored in real-time with the help of our advanced control panel. 
                Acquiring useful information to help in decision-making and optimize your operations.
              </p>
            </div>

            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <RefreshCw className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Automated Disbursements</h3>
              <p className="text-gray-600 leading-relaxed">
                Simplify payments for the vendors and employees. Improve effectiveness and 
                decrease paperwork with our automated disbursement solutions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Customized Payment Options Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Customized Payment Options
            </h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
            {/* E-commerce Section */}
            <div className="space-y-8">
              <h3 className="text-3xl font-bold text-gray-900">
                <span className="text-blue-600">E-commerce</span>
              </h3>
              
              <p className="text-lg text-gray-600 leading-relaxed">
                Ensure timely payments to sellers and vendors. Build trust and 
                satisfaction among your partners. Gradually increase the size of your 
                platform as the number of transactions increases. Minimize the 
                chances of human interference and mistakes in payment procedures.
              </p>
            </div>

            {/* E-commerce Animation */}
            <div className="relative">
              <div className="relative w-full h-80 bg-gradient-to-br from-purple-100 to-pink-100 rounded-3xl p-8 overflow-hidden">
                {/* Shopping Cart */}
                <div className="absolute left-8 top-1/2 transform -translate-y-1/2">
                  <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-orange-600 rounded-lg shadow-xl flex items-center justify-center">
                    <ShoppingCart className="w-8 h-8 text-white" />
                  </div>
                </div>

                {/* Mobile Payment */}
                <div className="absolute right-8 top-1/2 transform -translate-y-1/2">
                  <div className="w-20 h-32 bg-gradient-to-b from-gray-800 to-gray-900 rounded-xl shadow-xl border-2 border-gray-700">
                    <div className="p-2 pt-3">
                      <div className="h-24 bg-gradient-to-b from-purple-500 to-purple-700 rounded-lg relative overflow-hidden">
                        <div className="absolute top-2 left-2 right-2">
                          <div className="text-center mb-2">
                            <div className="text-white text-xs font-bold">PAYMENT</div>
                          </div>
                          <div className="bg-white/20 rounded p-1 mb-2 text-center">
                            <div className="text-white text-xs">₹2,499</div>
                          </div>
                          <div className="bg-green-500 rounded p-1 text-center animate-pulse">
                            <div className="text-white text-xs font-bold">PAY</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Person */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-12 h-16 bg-gradient-to-b from-purple-400 to-purple-600 rounded-t-full relative">
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-yellow-200 rounded-full"></div>
                  </div>
                </div>

                {/* Floating Elements */}
                <div className="absolute top-8 right-16 w-6 h-6 bg-green-400 rounded-full animate-bounce flex items-center justify-center">
                  <CheckCircle className="w-3 h-3 text-white" />
                </div>
                <div className="absolute bottom-8 left-16 w-4 h-4 bg-blue-400 rounded-full animate-pulse"></div>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Payroll Animation */}
            <div className="relative lg:order-1">
              <div className="relative w-full h-80 bg-gradient-to-br from-green-100 to-blue-100 rounded-3xl p-8 overflow-hidden">
                {/* ATM/Bank */}
                <div className="absolute left-8 top-1/2 transform -translate-y-1/2">
                  <div className="w-16 h-20 bg-gradient-to-b from-blue-600 to-blue-800 rounded-lg shadow-xl relative">
                    <div className="p-2">
                      <div className="h-12 bg-blue-300 rounded mb-2"></div>
                      <div className="grid grid-cols-3 gap-1">
                        {[...Array(9)].map((_, i) => (
                          <div key={i} className="w-2 h-2 bg-blue-400 rounded"></div>
                        ))}
                      </div>
                    </div>
                    <div className="absolute top-1 right-1 w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  </div>
                </div>

                {/* People */}
                <div className="absolute right-8 top-1/3">
                  <div className="w-12 h-16 bg-gradient-to-b from-green-400 to-green-600 rounded-t-full relative">
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-yellow-200 rounded-full"></div>
                  </div>
                </div>

                <div className="absolute right-12 bottom-1/3">
                  <div className="w-12 h-16 bg-gradient-to-b from-orange-400 to-orange-600 rounded-t-full relative">
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-yellow-200 rounded-full"></div>
                  </div>
                </div>

                {/* Money Flow */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-24 h-1 bg-gradient-to-r from-green-400 to-blue-500 rounded-full relative">
                    <div className="absolute top-1/2 transform -translate-y-1/2 w-3 h-3 bg-yellow-400 rounded-full animate-money-flow"></div>
                  </div>
                </div>

                {/* Coins */}
                <div className="absolute top-8 left-16 w-6 h-6 bg-yellow-400 rounded-full animate-bounce flex items-center justify-center">
                  <Banknote className="w-3 h-3 text-white" />
                </div>
                <div className="absolute bottom-8 right-16 w-4 h-4 bg-green-400 rounded-full animate-pulse"></div>
              </div>
            </div>

            {/* Payroll Section */}
            <div className="space-y-8 lg:order-2">
              <h3 className="text-3xl font-bold text-gray-900">
                Payroll <span className="text-blue-600">Services</span>
              </h3>
              
              <p className="text-lg text-gray-600 leading-relaxed">
                Provide payment frequencies that would be favorable to the 
                employees. Accept multiple forms of payment (direct deposit, prepaid 
                card, digital wallet). Reduce the complexity of payroll management, 
                legal requirements, and documentation. Enhance the satisfaction of 
                the employees through the provision of reliable and flexible payment 
                methods.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gray-900 via-blue-900 to-indigo-900 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-gray-900/90 via-blue-900/90 to-indigo-900/90"></div>
          <div className="absolute top-20 left-20 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 text-center relative z-10">
          <div className="max-w-4xl mx-auto space-y-8">
            <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
              Ready to choose SovaPay For Your Payment Operations?
            </h2>
            <p className="text-xl text-blue-100 leading-relaxed">
              Contact our team of specialists today to learn how SovaPay's payouts can transform your business. 
              Become one of the many businesses thriving with the help of SovaPay's sophisticated payout services 
              and elevate your financial management.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg">
                Contact Us
              </button>
              <button className="border-2 border-white/30 hover:border-white/50 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 hover:bg-white/10 backdrop-blur-sm">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      <style jsx>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .preserve-3d {
          transform-style: preserve-3d;
        }
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          33% { transform: translateY(-8px) translateX(4px) rotateZ(2deg); }
          66% { transform: translateY(4px) translateX(-2px) rotateZ(-1deg); }
        }
        @keyframes float-medium {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          50% { transform: translateY(-12px) translateX(6px) rotateZ(3deg); }
        }
        @keyframes money-flow {
          0% { left: 0; }
          100% { left: calc(100% - 12px); }
        }
        @keyframes coin-bounce {
          0%, 100% { transform: translateY(0px) rotateY(0deg); }
          25% { transform: translateY(-8px) rotateY(90deg); }
          50% { transform: translateY(-4px) rotateY(180deg); }
          75% { transform: translateY(-8px) rotateY(270deg); }
        }
        .animate-float-slow {
          animation: float-slow 6s ease-in-out infinite;
        }
        .animate-float-medium {
          animation: float-medium 4s ease-in-out infinite;
        }
        .animate-money-flow {
          animation: money-flow 3s ease-in-out infinite;
        }
        .animate-coin-bounce {
          animation: coin-bounce 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default PayoutSolutions;