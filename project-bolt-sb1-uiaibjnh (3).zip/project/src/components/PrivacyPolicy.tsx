import React from 'react';
import { 
  Shield, 
  Lock, 
  Eye, 
  FileText, 
  CheckCircle,
  Users,
  Database,
  Globe,
  AlertTriangle,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Settings,
  UserCheck,
  Fingerprint,
  Server
} from 'lucide-react';

const PrivacyPolicy = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Enhanced Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-64 h-64 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-br from-indigo-200/30 to-blue-200/30 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
          <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-gradient-to-br from-purple-200/20 to-pink-200/20 rounded-full blur-2xl animate-pulse" style={{animationDelay: '4s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-6">
                <div className="inline-flex items-center space-x-2 bg-blue-100 rounded-full px-4 py-2 border border-blue-200">
                  <Shield className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-700">Data Protection & Privacy</span>
                </div>

                <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  Privacy <span className="text-blue-600">Policy</span>
                </h1>
                
                <p className="text-lg text-gray-600 leading-relaxed">
                  At SovaPay Technologies, we are committed to protecting your privacy and ensuring 
                  the security of your personal information. This Privacy Policy explains how we collect, 
                  use, and safeguard your data when you use our financial technology services.
                </p>
              </div>

              <div className="flex items-center space-x-8 pt-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">GDPR Compliant</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">Bank-Level Security</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">Transparent Practices</span>
                </div>
              </div>
            </div>

            {/* Enhanced Right Content - Privacy Animation */}
            <div className="relative">
              <div className="relative w-full h-[500px] perspective-1000">
                {/* Enhanced Background Gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 to-purple-100/50 rounded-3xl overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-200/20 via-transparent to-purple-200/20"></div>
                </div>

                {/* Main 3D Scene Container */}
                <div className="absolute inset-0 transform-gpu preserve-3d" style={{transform: 'rotateX(10deg) rotateY(-10deg) translateZ(0)'}}>
                  
                  {/* Enhanced Privacy Shield */}
                  <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-20deg) rotateY(-15deg)'}}>
                      {/* Shield Shadow */}
                      <div className="absolute top-12 left-12 w-32 h-40 bg-black/15 rounded-t-full blur-xl transform skew-x-12 skew-y-6"></div>
                      
                      {/* Main Shield */}
                      <div className="w-32 h-40 bg-gradient-to-b from-blue-500 via-blue-600 to-blue-800 rounded-t-full shadow-2xl border-2 border-blue-300 relative overflow-hidden">
                        {/* Shield Highlight */}
                        <div className="absolute top-2 left-4 w-8 h-12 bg-white/30 rounded-t-full blur-sm"></div>
                        
                        {/* Shield Pattern */}
                        <div className="absolute inset-4 border-2 border-white/20 rounded-t-full"></div>
                        
                        {/* Lock Icon */}
                        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                            <Lock className="w-6 h-6 text-white" />
                          </div>
                        </div>
                        
                        {/* Security Indicators */}
                        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" style={{animationDelay: '0.3s'}}></div>
                          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" style={{animationDelay: '0.6s'}}></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Floating Privacy Icons */}
                  <div className="absolute top-20 right-20 animate-float-slow">
                    <div className="relative transform rotate-12">
                      <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-700 rounded-xl shadow-xl border border-green-300 flex items-center justify-center">
                        <UserCheck className="w-8 h-8 text-white" />
                      </div>
                    </div>
                  </div>

                  <div className="absolute bottom-24 left-8 animate-float-medium" style={{animationDelay: '1s'}}>
                    <div className="relative transform -rotate-12">
                      <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-700 rounded-xl shadow-xl border border-purple-300 flex items-center justify-center">
                        <Database className="w-8 h-8 text-white" />
                      </div>
                    </div>
                  </div>

                  <div className="absolute top-32 left-24 animate-float-fast" style={{animationDelay: '2s'}}>
                    <div className="relative transform rotate-6">
                      <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-orange-700 rounded-xl shadow-xl border border-orange-300 flex items-center justify-center">
                        <Fingerprint className="w-8 h-8 text-white" />
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Document Icons */}
                  <div className="absolute bottom-16 right-24 animate-float-slow" style={{animationDelay: '0.5s'}}>
                    <div className="relative">
                      <div className="w-12 h-16 bg-gradient-to-b from-blue-400 to-blue-600 rounded-lg shadow-xl border border-blue-300 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-2 h-2 bg-blue-200 rounded-full"></div>
                        <div className="absolute bottom-1 right-1">
                          <FileText className="w-4 h-4 text-white" />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                      </div>
                    </div>
                  </div>

                  {/* Network Connection Lines */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-80 h-80 border border-dashed border-blue-300/30 rounded-full animate-spin opacity-40" style={{animationDuration: '30s'}}></div>
                    <div className="absolute w-64 h-64 border border-dashed border-purple-300/25 rounded-full animate-spin opacity-35" style={{animationDuration: '25s', animationDirection: 'reverse'}}></div>
                  </div>

                  {/* Floating Particles */}
                  <div className="absolute top-16 left-40 w-2 h-2 bg-blue-400 rounded-full animate-ping"></div>
                  <div className="absolute bottom-20 left-24 w-1.5 h-1.5 bg-purple-400 rounded-full animate-ping" style={{animationDelay: '1s'}}></div>
                  <div className="absolute top-40 right-32 w-1 h-1 bg-green-400 rounded-full animate-ping" style={{animationDelay: '2s'}}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Privacy Policy Content */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="space-y-12">
              
              {/* Last Updated */}
              <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100">
                <div className="flex items-center space-x-3 mb-4">
                  <Calendar className="w-6 h-6 text-blue-600" />
                  <h3 className="text-lg font-bold text-gray-900">Last Updated</h3>
                </div>
                <p className="text-gray-600">This Privacy Policy was last updated on January 15, 2025. We may update this policy from time to time to reflect changes in our practices or legal requirements.</p>
              </div>

              {/* Section 1: Information We Collect */}
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
                    <Database className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900">1. Information We Collect</h2>
                </div>
                
                <div className="bg-gray-50 rounded-2xl p-8">
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Personal Information</h3>
                  <p className="text-gray-600 mb-6">When you use our services, we may collect the following types of personal information:</p>
                  
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span className="text-gray-700">Full Name and Contact Details</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span className="text-gray-700">Email Address and Phone Number</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span className="text-gray-700">Business Information</span>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span className="text-gray-700">Financial Transaction Data</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span className="text-gray-700">Device and Usage Information</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span className="text-gray-700">KYC Documentation</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 2: How We Use Your Information */}
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center">
                    <Settings className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900">2. How We Use Your Information</h2>
                </div>
                
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100">
                    <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center mb-4">
                      <UserCheck className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-3">Service Delivery</h3>
                    <p className="text-gray-600 text-sm">To provide, maintain, and improve our financial technology services including payments, transfers, and verification.</p>
                  </div>
                  
                  <div className="bg-green-50 rounded-2xl p-6 border border-green-100">
                    <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center mb-4">
                      <Shield className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-3">Security & Compliance</h3>
                    <p className="text-gray-600 text-sm">To ensure security, prevent fraud, and comply with legal and regulatory requirements including KYC and AML.</p>
                  </div>
                  
                  <div className="bg-purple-50 rounded-2xl p-6 border border-purple-100">
                    <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center mb-4">
                      <Users className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-3">Customer Support</h3>
                    <p className="text-gray-600 text-sm">To provide customer support, respond to inquiries, and communicate important service updates.</p>
                  </div>
                </div>
              </div>

              {/* Section 3: Data Protection & Security */}
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
                    <Lock className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900">3. Data Protection & Security</h2>
                </div>
                
                <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-8 border border-blue-100">
                  <div className="grid md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <h3 className="text-xl font-bold text-gray-900">Security Measures</h3>
                      <div className="space-y-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                            <CheckCircle className="w-4 h-4 text-white" />
                          </div>
                          <span className="text-gray-700">256-bit SSL Encryption</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                            <CheckCircle className="w-4 h-4 text-white" />
                          </div>
                          <span className="text-gray-700">Multi-Factor Authentication</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                            <CheckCircle className="w-4 h-4 text-white" />
                          </div>
                          <span className="text-gray-700">Regular Security Audits</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="text-xl font-bold text-gray-900">Compliance Standards</h3>
                      <div className="space-y-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                            <CheckCircle className="w-4 h-4 text-white" />
                          </div>
                          <span className="text-gray-700">RBI Guidelines Compliance</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                            <CheckCircle className="w-4 h-4 text-white" />
                          </div>
                          <span className="text-gray-700">GDPR Data Protection</span>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                            <CheckCircle className="w-4 h-4 text-white" />
                          </div>
                          <span className="text-gray-700">ISO 27001 Certified</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 4: Your Rights */}
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center">
                    <Eye className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900">4. Your Privacy Rights</h2>
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
                      <h3 className="text-lg font-bold text-gray-900 mb-3">Access & Portability</h3>
                      <p className="text-gray-600 text-sm">You have the right to access your personal data and request a copy in a portable format.</p>
                    </div>
                    
                    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
                      <h3 className="text-lg font-bold text-gray-900 mb-3">Correction & Updates</h3>
                      <p className="text-gray-600 text-sm">You can request corrections to inaccurate or incomplete personal information.</p>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
                      <h3 className="text-lg font-bold text-gray-900 mb-3">Deletion & Erasure</h3>
                      <p className="text-gray-600 text-sm">You may request deletion of your personal data, subject to legal and regulatory requirements.</p>
                    </div>
                    
                    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100">
                      <h3 className="text-lg font-bold text-gray-900 mb-3">Consent Withdrawal</h3>
                      <p className="text-gray-600 text-sm">You can withdraw consent for data processing where consent is the legal basis.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 5: Data Sharing */}
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl flex items-center justify-center">
                    <Globe className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900">5. Data Sharing & Third Parties</h2>
                </div>
                
                <div className="bg-yellow-50 rounded-2xl p-8 border border-yellow-200">
                  <div className="flex items-start space-x-4">
                    <AlertTriangle className="w-8 h-8 text-yellow-600 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-4">Limited Data Sharing</h3>
                      <p className="text-gray-700 mb-4">We only share your personal information in the following circumstances:</p>
                      <ul className="space-y-2 text-gray-600">
                        <li>• With your explicit consent</li>
                        <li>• To comply with legal obligations and regulatory requirements</li>
                        <li>• With trusted service providers who assist in delivering our services</li>
                        <li>• To prevent fraud and ensure transaction security</li>
                        <li>• In case of business transfers (mergers, acquisitions)</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 rounded-2xl p-8 text-white">
                <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold mb-4">Privacy Questions?</h2>
                  <p className="text-blue-100 text-lg">Contact our Data Protection Officer for any privacy-related inquiries</p>
                </div>
                
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Mail className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-bold mb-2">Email</h3>
                    <p className="text-blue-100">privacy@sovapay.net</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Phone className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-bold mb-2">Phone</h3>
                    <p className="text-blue-100">+91 9654607040</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <MapPin className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-bold mb-2">Address</h3>
                    <p className="text-blue-100">44 IIND FLOOR REGAL BUILDING, CONNAUGHT PLACE, NEW DELHI</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <style jsx>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .preserve-3d {
          transform-style: preserve-3d;
        }
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          33% { transform: translateY(-8px) translateX(4px) rotateZ(2deg); }
          66% { transform: translateY(4px) translateX(-2px) rotateZ(-1deg); }
        }
        @keyframes float-medium {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          50% { transform: translateY(-12px) translateX(6px) rotateZ(3deg); }
        }
        @keyframes float-fast {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          25% { transform: translateY(-6px) translateX(3px) rotateZ(1deg); }
          75% { transform: translateY(6px) translateX(-3px) rotateZ(-2deg); }
        }
        .animate-float-slow {
          animation: float-slow 6s ease-in-out infinite;
        }
        .animate-float-medium {
          animation: float-medium 4s ease-in-out infinite;
        }
        .animate-float-fast {
          animation: float-fast 3s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default PrivacyPolicy;