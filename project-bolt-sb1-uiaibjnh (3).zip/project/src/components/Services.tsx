import React from 'react';
import { ArrowRight, Server, Smartphone, Database, Wifi, Code, Building2 } from 'lucide-react';

const Services = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-6">
        {/* Services Grid */}
        <div className="space-y-20">
          {/* Service 1 */}
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              {/* Fintech Machine Animation */}
              <div className="relative w-full h-80 bg-gradient-to-br from-green-50 to-blue-50 rounded-3xl p-8 overflow-hidden">
                {/* Floating Cubes */}
                <div className="absolute top-6 right-6 w-8 h-8 bg-blue-500 rounded transform rotate-45 animate-bounce"></div>
                <div className="absolute top-16 left-6 w-6 h-6 bg-blue-400 rounded transform rotate-12 animate-pulse"></div>
                <div className="absolute bottom-8 right-12 w-5 h-5 bg-blue-600 rounded transform -rotate-12 animate-bounce delay-300"></div>
                
                {/* Main Server/Machine */}
                <div className="absolute right-8 top-1/2 transform -translate-y-1/2">
                  <div className="w-20 h-32 bg-gradient-to-b from-blue-600 to-blue-800 rounded-lg shadow-xl">
                    {/* Server Panels */}
                    <div className="p-2 space-y-1">
                      <div className="h-3 bg-blue-300 rounded animate-pulse"></div>
                      <div className="h-3 bg-blue-300 rounded animate-pulse delay-100"></div>
                      <div className="h-3 bg-blue-300 rounded animate-pulse delay-200"></div>
                      <div className="h-3 bg-blue-300 rounded animate-pulse delay-300"></div>
                      <div className="h-3 bg-blue-300 rounded animate-pulse delay-400"></div>
                    </div>
                    {/* Server Base */}
                    <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-blue-400 rounded-full animate-pulse"></div>
                  </div>
                </div>
                
                {/* Mobile Phone */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-16 h-28 bg-gradient-to-b from-gray-800 to-gray-900 rounded-xl shadow-xl border-2 border-gray-700">
                    <div className="p-2 pt-3">
                      {/* Screen */}
                      <div className="h-20 bg-gradient-to-b from-purple-400 to-blue-500 rounded-lg relative overflow-hidden">
                        {/* App Interface */}
                        <div className="absolute top-2 left-2 right-2">
                          <div className="h-1 bg-white/30 rounded mb-1"></div>
                          <div className="h-1 bg-white/30 rounded w-3/4 mb-1"></div>
                          <div className="h-1 bg-white/30 rounded w-1/2"></div>
                        </div>
                        {/* Floating coins */}
                        <div className="absolute bottom-2 right-2 w-3 h-3 bg-yellow-400 rounded-full animate-bounce"></div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Golden Coins Stack */}
                <div className="absolute left-8 bottom-12">
                  <div className="relative">
                    <div className="w-8 h-2 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full"></div>
                    <div className="w-8 h-2 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full -mt-1"></div>
                    <div className="w-8 h-2 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full -mt-1"></div>
                    <div className="absolute -top-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-yellow-300 rounded-full animate-ping"></div>
                  </div>
                </div>
                
                {/* Connection Lines */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-48 h-48 border border-dashed border-blue-300 rounded-full opacity-30 animate-spin" style={{animationDuration: '20s'}}></div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <h3 className="text-3xl font-bold text-gray-900">Streamlined Payment Solutions</h3>
              <p className="text-lg text-gray-600 leading-relaxed">
                We have ensured that accepting payments is as easy as can be. Whether you are an online business or a physical store, our system ensures that the transactions are seamless and safe.
              </p>
            </div>
          </div>

          {/* Service 2 */}
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 lg:order-2">
              <h3 className="text-3xl font-bold text-gray-900">Everything in One Place</h3>
              <p className="text-lg text-gray-600 leading-relaxed">
                Managing a business is not a joke. That is why we have developed a single platform for all your software and financial requirements. Fewer problems, more concentration on the essentials.
              </p>
            </div>
            
            <div className="relative lg:order-1">
              {/* Animated Hub Illustration */}
              <div className="relative w-full h-80 bg-gradient-to-br from-green-100 to-blue-100 rounded-3xl p-8 overflow-hidden">
                {/* Central Hub */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full shadow-lg flex items-center justify-center">
                    <Database className="w-8 h-8 text-white" />
                  </div>
                </div>
                
                {/* Orbiting Elements */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-40 h-40 border-2 border-dashed border-blue-300 rounded-full animate-spin" style={{animationDuration: '10s'}}>
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-green-500 rounded-full"></div>
                    <div className="absolute -right-3 top-1/2 transform -translate-y-1/2 w-6 h-6 bg-yellow-500 rounded-full"></div>
                    <div className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-red-500 rounded-full"></div>
                    <div className="absolute -left-3 top-1/2 transform -translate-y-1/2 w-6 h-6 bg-purple-500 rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Service 3 */}
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              {/* Animated Building Blocks */}
              <div className="relative w-full h-80 bg-gradient-to-br from-purple-100 to-pink-100 rounded-3xl p-8 overflow-hidden">
                {/* Building Blocks */}
                <div className="absolute left-1/4 top-1/3">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-700 rounded-lg shadow-lg transform rotate-12 animate-pulse">
                    <div className="p-2">
                      <Code className="w-12 h-12 text-white" />
                    </div>
                  </div>
                </div>
                
                <div className="absolute right-1/4 top-1/4">
                  <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-700 rounded-lg shadow-lg transform -rotate-12 animate-pulse delay-300">
                    <div className="p-2">
                      <Building2 className="w-12 h-12 text-white" />
                    </div>
                  </div>
                </div>
                
                <div className="absolute left-1/2 bottom-1/3 transform -translate-x-1/2">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-700 rounded-lg shadow-lg animate-pulse delay-150">
                    <div className="p-2">
                      <Server className="w-12 h-12 text-white" />
                    </div>
                  </div>
                </div>
                
                {/* Connecting Lines */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-32 h-32 border-2 border-dashed border-purple-300 rounded-full opacity-50"></div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              <h3 className="text-3xl font-bold text-gray-900">Built for Your Business</h3>
              <p className="text-lg text-gray-600 leading-relaxed">
                Every company is unique. Our services are custom-made to meet your needs and objectives, guaranteeing you the assistance you need to excel.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;