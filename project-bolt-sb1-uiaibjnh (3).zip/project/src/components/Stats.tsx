import React from 'react';
import { TrendingUp, Users, Shield, Award } from 'lucide-react';

interface StatsProps {
  setCurrentPage: (page: string) => void;
}

const Stats = ({ setCurrentPage }: StatsProps) => {
  const stats = [
    {
      icon: <Users className="w-8 h-8 text-blue-600" />,
      number: "98,000+",
      label: "Active Retailers",
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: <TrendingUp className="w-8 h-8 text-purple-600" />,
      number: "1,12,000+",
      label: "Onboarded Clients",
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: <Shield className="w-8 h-8 text-green-600" />,
      number: "90%+",
      label: "Clients Retention Rate",
      color: "from-green-500 to-emerald-500"
    },
    {
      icon: <Award className="w-8 h-8 text-orange-600" />,
      number: "Expert Team",
      label: "Professional Support",
      color: "from-orange-500 to-red-500"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Why <span className="text-blue-600">SovaPay</span>?
          </h2>
          <div className="space-y-4 text-lg text-gray-600 max-w-3xl mx-auto">
            <p>• Working experience in software and finance for years</p>
            <p>• Solutions that are easy for the users to implement while solving complicated issues</p>
            <p>• Services that can change with your business as it grows</p>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow">
              <div className={`w-16 h-16 bg-gradient-to-r ${stat.color} rounded-2xl flex items-center justify-center mb-6`}>
                {stat.icon}
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
              <div className="text-gray-600 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>

         {/* Dashboard Preview */}
          <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-8 border border-gray-200/50 shadow-lg">
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl p-6 text-white">
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              </div>
              <div className="font-mono text-sm">
                <div className="text-green-400">// Initialize SovaPay</div>
                <div className="text-blue-400">const sovapay = new SovaPay(&lbrace;</div>
                <div className="text-white ml-4">apiKey: 'your_api_key',</div>
                <div className="text-white ml-4">environment: 'production'</div>
                <div className="text-blue-400">&rbrace;);</div>
                <div className="mt-4 text-green-400">// Create payment</div>
                <div className="text-blue-400">const payment = await sovapay.payments.create(&lbrace;</div>
                <div className="text-white ml-4">amount: 10000,</div>
                <div className="text-white ml-4">currency: 'INR',</div>
                <div className="text-white ml-4">customer_id: 'cust_123'</div>
                <div className="text-blue-400">&rbrace;);</div>
              </div>
            </div>
          </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-gray-900 to-blue-900 rounded-3xl p-12 text-white text-center">
          <h3 className="text-3xl font-bold mb-4">Let's Work Together</h3>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Are you ready to level up your business? We would like to discuss with 
            you the features that will allow SovaPay to meet your objectives.
          </p>
          <button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105">
            Get Started Today
          </button>
        </div>
      </div>
    </section>
  );
};

export default Stats;