import React from 'react';
import { 
  FileText, 
  Shield, 
  Scale, 
  CheckCircle,
  Users,
  Database,
  Globe,
  AlertTriangle,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Settings,
  UserCheck,
  Lock,
  Eye,
  Gavel,
  BookOpen,
  CreditCard
} from 'lucide-react';

const TermsConditions = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Enhanced Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-64 h-64 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-br from-indigo-200/30 to-blue-200/30 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
          <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-gradient-to-br from-purple-200/20 to-pink-200/20 rounded-full blur-2xl animate-pulse" style={{animationDelay: '4s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-6">
                <div className="inline-flex items-center space-x-2 bg-blue-100 rounded-full px-4 py-2 border border-blue-200">
                  <Scale className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-700">Legal Terms & Service Agreement</span>
                </div>

                <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  Terms & <span className="text-blue-600">Conditions</span>
                </h1>
                
                <p className="text-lg text-gray-600 leading-relaxed">
                  Welcome to SovaPay Technologies. These Terms and Conditions govern your use of our 
                  financial technology services and platform. By accessing or using our services, you 
                  agree to be bound by these terms. Please read them carefully to understand your rights 
                  and obligations when using our fintech solutions.
                </p>
              </div>

              <div className="flex items-center space-x-8 pt-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">Legally Binding</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">RBI Compliant</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">User Protection</span>
                </div>
              </div>
            </div>

            {/* Enhanced Right Content - Legal Document Animation */}
            <div className="relative">
              <div className="relative w-full h-[500px] perspective-1000">
                {/* Enhanced Background Gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 to-purple-100/50 rounded-3xl overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-200/20 via-transparent to-purple-200/20"></div>
                </div>

                {/* Main 3D Scene Container */}
                <div className="absolute inset-0 transform-gpu preserve-3d" style={{transform: 'rotateX(10deg) rotateY(-10deg) translateZ(0)'}}>
                  
                  {/* Enhanced Legal Document */}
                  <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-20deg) rotateY(-15deg)'}}>
                      {/* Document Shadow */}
                      <div className="absolute top-12 left-12 w-32 h-44 bg-black/15 rounded-xl blur-xl transform skew-x-12 skew-y-6"></div>
                      
                      {/* Main Document */}
                      <div className="w-32 h-44 bg-gradient-to-b from-white via-gray-50 to-gray-100 rounded-xl shadow-2xl border border-gray-200 relative overflow-hidden">
                        {/* Document Highlight */}
                        <div className="absolute top-2 left-2 w-8 h-12 bg-white/60 rounded blur-sm"></div>
                        
                        {/* Document Header */}
                        <div className="p-3">
                          <div className="h-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded mb-2 flex items-center justify-center">
                            <span className="text-white text-xs font-bold">TERMS</span>
                          </div>
                          
                          {/* Document Content Lines */}
                          <div className="space-y-1 mb-3">
                            <div className="h-1 bg-gray-400 rounded"></div>
                            <div className="h-1 bg-gray-400 rounded w-4/5"></div>
                            <div className="h-1 bg-gray-400 rounded w-3/5"></div>
                            <div className="h-1 bg-gray-400 rounded w-5/6"></div>
                            <div className="h-1 bg-gray-400 rounded w-2/3"></div>
                          </div>
                          
                          {/* Legal Sections */}
                          <div className="space-y-2">
                            <div className="flex items-center space-x-1">
                              <div className="w-1 h-1 bg-blue-500 rounded-full"></div>
                              <div className="h-0.5 bg-gray-500 rounded flex-1"></div>
                            </div>
                            <div className="flex items-center space-x-1">
                              <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                              <div className="h-0.5 bg-gray-500 rounded flex-1"></div>
                            </div>
                            <div className="flex items-center space-x-1">
                              <div className="w-1 h-1 bg-purple-500 rounded-full"></div>
                              <div className="h-0.5 bg-gray-500 rounded flex-1"></div>
                            </div>
                          </div>
                          
                          {/* Signature Area */}
                          <div className="mt-4 pt-2 border-t border-gray-300">
                            <div className="h-1 bg-blue-500 rounded w-1/2"></div>
                          </div>
                        </div>
                        
                        {/* Legal Seal */}
                        <div className="absolute bottom-2 right-2 w-6 h-6 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                          <Scale className="w-3 h-3 text-white" />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Floating Legal Icons */}
                  <div className="absolute top-20 right-20 animate-float-slow">
                    <div className="relative transform rotate-12">
                      <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl shadow-xl border border-blue-300 flex items-center justify-center">
                        <Gavel className="w-8 h-8 text-white" />
                      </div>
                    </div>
                  </div>

                  <div className="absolute bottom-24 left-8 animate-float-medium" style={{animationDelay: '1s'}}>
                    <div className="relative transform -rotate-12">
                      <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-700 rounded-xl shadow-xl border border-green-300 flex items-center justify-center">
                        <BookOpen className="w-8 h-8 text-white" />
                      </div>
                    </div>
                  </div>

                  <div className="absolute top-32 left-24 animate-float-fast" style={{animationDelay: '2s'}}>
                    <div className="relative transform rotate-6">
                      <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-700 rounded-xl shadow-xl border border-purple-300 flex items-center justify-center">
                        <Shield className="w-8 h-8 text-white" />
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Document Icons */}
                  <div className="absolute bottom-16 right-24 animate-float-slow" style={{animationDelay: '0.5s'}}>
                    <div className="relative">
                      <div className="w-12 h-16 bg-gradient-to-b from-orange-400 to-orange-600 rounded-lg shadow-xl border border-orange-300 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-2 h-2 bg-orange-200 rounded-full"></div>
                        <div className="absolute bottom-1 right-1">
                          <FileText className="w-4 h-4 text-white" />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                      </div>
                    </div>
                  </div>

                  {/* Network Connection Lines */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-80 h-80 border border-dashed border-blue-300/30 rounded-full animate-spin opacity-40" style={{animationDuration: '30s'}}></div>
                    <div className="absolute w-64 h-64 border border-dashed border-purple-300/25 rounded-full animate-spin opacity-35" style={{animationDuration: '25s', animationDirection: 'reverse'}}></div>
                  </div>

                  {/* Floating Particles */}
                  <div className="absolute top-16 left-40 w-2 h-2 bg-blue-400 rounded-full animate-ping"></div>
                  <div className="absolute bottom-20 left-24 w-1.5 h-1.5 bg-purple-400 rounded-full animate-ping" style={{animationDelay: '1s'}}></div>
                  <div className="absolute top-40 right-32 w-1 h-1 bg-green-400 rounded-full animate-ping" style={{animationDelay: '2s'}}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Terms & Conditions Content */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto">
            <div className="space-y-12">
              
              {/* Last Updated */}
              <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100">
                <div className="flex items-center space-x-3 mb-4">
                  <Calendar className="w-6 h-6 text-blue-600" />
                  <h3 className="text-lg font-bold text-gray-900">Last Updated</h3>
                </div>
                <p className="text-gray-600">These Terms and Conditions were last updated on January 15, 2025. We may update these terms from time to time to reflect changes in our services or legal requirements.</p>
              </div>

              {/* Section 1: Acceptance of Terms */}
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center">
                    <UserCheck className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900">1. Acceptance of Terms</h2>
                </div>
                
                <div className="bg-gray-50 rounded-2xl p-8">
                  <p className="text-gray-600 mb-6">By accessing and using SovaPay Technologies' services, you acknowledge that you have read, understood, and agree to be bound by these Terms and Conditions.</p>
                  
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-1" />
                      <span className="text-gray-700">You must be at least 18 years old to use our services</span>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-1" />
                      <span className="text-gray-700">You have the legal capacity to enter into binding agreements</span>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-500 mt-1" />
                      <span className="text-gray-700">Your use of our services constitutes acceptance of these terms</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 2: Service Description */}
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900">2. Service Description</h2>
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100">
                    <h3 className="text-lg font-bold text-gray-900 mb-3">Financial Services</h3>
                    <ul className="space-y-2 text-gray-600 text-sm">
                      <li>• AePS (Aadhaar Enabled Payment System)</li>
                      <li>• Domestic Money Transfer (DMT)</li>
                      <li>• Utility Bill Payment Solutions</li>
                      <li>• Micro ATM Services</li>
                      <li>• KYC and Identity Verification</li>
                    </ul>
                  </div>
                  
                  <div className="bg-green-50 rounded-2xl p-6 border border-green-100">
                    <h3 className="text-lg font-bold text-gray-900 mb-3">Technology Solutions</h3>
                    <ul className="space-y-2 text-gray-600 text-sm">
                      <li>• Fintech Software Development</li>
                      <li>• Payment Gateway Integration</li>
                      <li>• Payout Solutions</li>
                      <li>• API Services and Documentation</li>
                      <li>• Technical Support and Maintenance</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Section 3: User Responsibilities */}
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center">
                    <Users className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900">3. User Responsibilities</h2>
                </div>
                
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-8 border border-purple-100">
                  <div className="space-y-4">
                    <div className="flex items-start space-x-4">
                      <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <CheckCircle className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900 mb-2">Account Security</h3>
                        <p className="text-gray-600 text-sm">You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-4">
                      <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <CheckCircle className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900 mb-2">Accurate Information</h3>
                        <p className="text-gray-600 text-sm">You must provide accurate, current, and complete information during registration and keep your information updated.</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-4">
                      <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <CheckCircle className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900 mb-2">Compliance</h3>
                        <p className="text-gray-600 text-sm">You must comply with all applicable laws, regulations, and these Terms when using our services.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 4: Prohibited Activities */}
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-red-600 rounded-xl flex items-center justify-center">
                    <AlertTriangle className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900">4. Prohibited Activities</h2>
                </div>
                
                <div className="bg-red-50 rounded-2xl p-8 border border-red-200">
                  <div className="flex items-start space-x-4">
                    <AlertTriangle className="w-8 h-8 text-red-600 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-4">Strictly Prohibited</h3>
                      <div className="grid md:grid-cols-2 gap-4">
                        <ul className="space-y-2 text-gray-700">
                          <li>• Fraudulent or illegal activities</li>
                          <li>• Money laundering or terrorist financing</li>
                          <li>• Unauthorized access to systems</li>
                          <li>• Violation of intellectual property rights</li>
                        </ul>
                        <ul className="space-y-2 text-gray-700">
                          <li>• Transmission of malicious software</li>
                          <li>• Interference with service operations</li>
                          <li>• Misrepresentation of identity</li>
                          <li>• Violation of privacy rights</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 5: Limitation of Liability */}
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center">
                    <Shield className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900">5. Limitation of Liability</h2>
                </div>
                
                <div className="bg-orange-50 rounded-2xl p-8 border border-orange-200">
                  <p className="text-gray-700 mb-4">
                    SovaPay Technologies provides services on an "as is" and "as available" basis. We make no warranties, 
                    express or implied, regarding the accuracy, reliability, or availability of our services.
                  </p>
                  <p className="text-gray-700">
                    To the maximum extent permitted by law, SovaPay Technologies shall not be liable for any indirect, 
                    incidental, special, consequential, or punitive damages arising from your use of our services.
                  </p>
                </div>
              </div>

              {/* Section 6: Governing Law */}
              <div className="space-y-6">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl flex items-center justify-center">
                    <Gavel className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900">6. Governing Law & Jurisdiction</h2>
                </div>
                
                <div className="bg-indigo-50 rounded-2xl p-8 border border-indigo-200">
                  <p className="text-gray-700 mb-4">
                    These Terms and Conditions are governed by and construed in accordance with the laws of India. 
                    Any disputes arising from these terms shall be subject to the exclusive jurisdiction of the courts 
                    in New Delhi, India.
                  </p>
                  <div className="flex items-center space-x-3">
                    <MapPin className="w-5 h-5 text-indigo-600" />
                    <span className="text-gray-700 font-medium">Jurisdiction: New Delhi, India</span>
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 rounded-2xl p-8 text-white">
                <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold mb-4">Questions About These Terms?</h2>
                  <p className="text-blue-100 text-lg">Contact our legal team for any questions regarding these Terms and Conditions</p>
                </div>
                
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Mail className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-bold mb-2">Email</h3>
                    <p className="text-blue-100">legal@sovapay.net</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <Phone className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-bold mb-2">Phone</h3>
                    <p className="text-blue-100">+91 9654607040</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <MapPin className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-bold mb-2">Address</h3>
                    <p className="text-blue-100">44 IIND FLOOR REGAL BUILDING, CONNAUGHT PLACE, NEW DELHI</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <style jsx>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .preserve-3d {
          transform-style: preserve-3d;
        }
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          33% { transform: translateY(-8px) translateX(4px) rotateZ(2deg); }
          66% { transform: translateY(4px) translateX(-2px) rotateZ(-1deg); }
        }
        @keyframes float-medium {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          50% { transform: translateY(-12px) translateX(6px) rotateZ(3deg); }
        }
        @keyframes float-fast {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          25% { transform: translateY(-6px) translateX(3px) rotateZ(1deg); }
          75% { transform: translateY(6px) translateX(-3px) rotateZ(-2deg); }
        }
        .animate-float-slow {
          animation: float-slow 6s ease-in-out infinite;
        }
        .animate-float-medium {
          animation: float-medium 4s ease-in-out infinite;
        }
        .animate-float-fast {
          animation: float-fast 3s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default TermsConditions;