import React from 'react';
import { 
  Zap, 
  Smartphone, 
  CreditCard, 
  CheckCircle,
  ArrowRight,
  Users,
  TrendingUp,
  Shield,
  Globe,
  Wifi,
  Building2,
  DollarSign,
  Clock,
  Star,
  Target,
  Award
} from 'lucide-react';

const UtilityServices = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Enhanced Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-64 h-64 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-80 h-80 bg-gradient-to-br from-indigo-200/30 to-blue-200/30 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
          <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-gradient-to-br from-purple-200/20 to-pink-200/20 rounded-full blur-2xl animate-pulse" style={{animationDelay: '4s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-6">
                <div className="inline-flex items-center space-x-2 bg-blue-100 rounded-full px-4 py-2 border border-blue-200">
                  <Zap className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-700">BBPS & Utility Services</span>
                </div>

                <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  Utility <span className="text-blue-600">Bill Payment</span> And <span className="text-purple-600">Recharge</span>
                </h1>
                
                <p className="text-lg text-gray-600 leading-relaxed">
                  Transform your shop into a convenient bill payment and recharge center with 
                  SovaPay's BBPS and Utility Services.
                </p>

                <div className="space-y-4 text-gray-600">
                  <p>
                    Merchants can help customers to pay utility bills and mobile/DTH 
                    connections, especially in those areas where there are no other options.
                  </p>
                  <p>
                    Consumers can get these basic services locally without having to wait for 
                    long, while the merchants get commissions on each sale.
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105 shadow-lg">
                  <span>Start Now</span>
                  <ArrowRight className="w-5 h-5" />
                </button>
                
                <button className="border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-4 rounded-full font-semibold transition-all duration-300">
                  Learn More
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="flex items-center space-x-8 pt-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">Instant Processing</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">High Commission</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-gray-600">24/7 Support</span>
                </div>
              </div>
            </div>

            {/* Enhanced Right Content - Premium Utility Payment Animation */}
            <div className="relative">
              <div className="relative w-full h-[500px] perspective-1000">
                {/* Enhanced Background Gradient */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 to-purple-100/50 rounded-3xl overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-200/20 via-transparent to-purple-200/20"></div>
                </div>

                {/* Main 3D Scene Container */}
                <div className="absolute inset-0 transform-gpu preserve-3d" style={{transform: 'rotateX(10deg) rotateY(-10deg) translateZ(0)'}}>
                  
                  {/* Enhanced Person with Mobile */}
                  <div className="absolute left-16 top-1/2 transform -translate-y-1/2">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-15deg) rotateY(20deg)'}}>
                      {/* Person Shadow */}
                      <div className="absolute top-12 left-12 w-20 h-32 bg-black/15 rounded-t-full blur-lg transform skew-x-6 skew-y-6"></div>
                      
                      {/* Person Body */}
                      <div className="w-20 h-32 bg-gradient-to-b from-orange-400 to-orange-600 rounded-t-full relative overflow-hidden shadow-2xl">
                        {/* Person Highlight */}
                        <div className="absolute top-2 left-2 w-6 h-8 bg-white/30 rounded blur-sm"></div>
                        
                        {/* Head */}
                        <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-yellow-200 rounded-full shadow-lg border-2 border-yellow-100"></div>
                        
                        {/* Mobile in Hand */}
                        <div className="absolute top-4 right-2">
                          <div className="w-6 h-10 bg-gradient-to-b from-gray-800 to-gray-900 rounded shadow-lg border border-gray-700">
                            <div className="p-0.5 pt-1">
                              <div className="h-7 bg-gradient-to-b from-blue-500 to-blue-700 rounded relative overflow-hidden">
                                {/* Bill Payment Interface */}
                                <div className="absolute top-1 left-1 right-1">
                                  <div className="text-center mb-1">
                                    <div className="text-white text-xs font-bold">PAY</div>
                                  </div>
                                  
                                  {/* Bill Amount */}
                                  <div className="bg-white/20 rounded p-0.5 mb-1 text-center">
                                    <div className="text-white text-xs">₹1,250</div>
                                  </div>
                                  
                                  {/* Pay Button */}
                                  <div className="bg-green-500 rounded p-0.5 text-center animate-pulse">
                                    <div className="text-white text-xs font-bold">PAY</div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {/* Checkmark Success */}
                        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2">
                          <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
                            <CheckCircle className="w-2 h-2 text-white" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Desktop/Tablet Interface */}
                  <div className="absolute right-12 top-16">
                    <div className="relative transform-gpu preserve-3d" style={{transform: 'rotateX(-20deg) rotateY(-30deg)'}}>
                      {/* Device Shadow */}
                      <div className="absolute top-12 left-12 w-40 h-28 bg-black/15 rounded-xl blur-xl transform skew-x-12 skew-y-6"></div>
                      
                      {/* Main Device */}
                      <div className="w-40 h-28 bg-gradient-to-b from-gray-100 to-gray-200 rounded-xl shadow-2xl border border-gray-300 relative overflow-hidden">
                        {/* Device Highlight */}
                        <div className="absolute top-1 left-2 w-10 h-6 bg-white/60 rounded blur-sm"></div>
                        
                        {/* Right Side */}
                        <div className="absolute top-0 -right-4 w-4 h-28 bg-gradient-to-b from-gray-200 to-gray-400 transform skew-y-12 shadow-lg"></div>
                        
                        {/* Top Side */}
                        <div className="absolute -top-3 left-0 w-40 h-3 bg-gradient-to-r from-gray-50 to-gray-200 transform skew-x-12 shadow-lg"></div>
                        
                        {/* Screen Content */}
                        <div className="p-3">
                          {/* Header */}
                          <div className="h-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded mb-2 flex items-center justify-center">
                            <span className="text-white text-xs font-bold">UTILITY BILLS</span>
                          </div>
                          
                          {/* Bill Categories */}
                          <div className="grid grid-cols-2 gap-1 mb-2">
                            <div className="h-4 bg-gradient-to-r from-yellow-400 to-orange-500 rounded flex items-center justify-center">
                              <Zap className="w-2 h-2 text-white" />
                            </div>
                            <div className="h-4 bg-gradient-to-r from-blue-400 to-blue-600 rounded flex items-center justify-center">
                              <Wifi className="w-2 h-2 text-white" />
                            </div>
                            <div className="h-4 bg-gradient-to-r from-green-400 to-green-600 rounded flex items-center justify-center">
                              <Smartphone className="w-2 h-2 text-white" />
                            </div>
                            <div className="h-4 bg-gradient-to-r from-purple-400 to-purple-600 rounded flex items-center justify-center">
                              <Globe className="w-2 h-2 text-white" />
                            </div>
                          </div>
                          
                          {/* Payment Status */}
                          <div className="h-3 bg-gradient-to-r from-green-400 to-green-600 rounded flex items-center justify-center">
                            <span className="text-white text-xs font-bold">SUCCESS</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Floating Bill Icons */}
                  <div className="absolute top-20 right-20 animate-float-slow">
                    <div className="relative transform rotate-12">
                      <div className="w-12 h-16 bg-gradient-to-b from-yellow-400 to-orange-500 rounded shadow-xl border border-yellow-300 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-2 h-2 bg-yellow-200 rounded-full"></div>
                        <div className="absolute bottom-1 right-1">
                          <Zap className="w-3 h-3 text-white" />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-white text-xs font-bold">ELEC</div>
                      </div>
                    </div>
                  </div>

                  <div className="absolute bottom-24 left-8 animate-float-medium" style={{animationDelay: '1s'}}>
                    <div className="relative transform -rotate-12">
                      <div className="w-12 h-16 bg-gradient-to-b from-blue-400 to-blue-600 rounded shadow-xl border border-blue-300 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-2 h-2 bg-blue-200 rounded-full"></div>
                        <div className="absolute bottom-1 right-1">
                          <Wifi className="w-3 h-3 text-white" />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-white text-xs font-bold">NET</div>
                      </div>
                    </div>
                  </div>

                  <div className="absolute top-32 left-24 animate-float-fast" style={{animationDelay: '2s'}}>
                    <div className="relative transform rotate-6">
                      <div className="w-12 h-16 bg-gradient-to-b from-green-400 to-green-600 rounded shadow-xl border border-green-300 relative overflow-hidden">
                        <div className="absolute top-1 left-1 w-2 h-2 bg-green-200 rounded-full"></div>
                        <div className="absolute bottom-1 right-1">
                          <Smartphone className="w-3 h-3 text-white" />
                        </div>
                        <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-white text-xs font-bold">MOB</div>
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Golden Coins */}
                  <div className="absolute bottom-16 right-24 animate-coin-bounce">
                    <div className="relative">
                      <div className="w-8 h-8 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-xs">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-8 h-2 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  <div className="absolute top-40 right-32 animate-coin-bounce" style={{animationDelay: '0.5s'}}>
                    <div className="relative">
                      <div className="w-6 h-6 bg-gradient-to-br from-yellow-300 via-yellow-400 to-orange-500 rounded-full shadow-xl border-2 border-yellow-200 flex items-center justify-center">
                        <span className="text-white font-bold text-xs">₹</span>
                      </div>
                      <div className="absolute -bottom-1 left-0 w-6 h-1.5 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-full"></div>
                    </div>
                  </div>

                  {/* Network Connection Lines */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-80 h-80 border border-dashed border-blue-300/30 rounded-full animate-spin opacity-40" style={{animationDuration: '30s'}}></div>
                    <div className="absolute w-64 h-64 border border-dashed border-purple-300/25 rounded-full animate-spin opacity-35" style={{animationDuration: '25s', animationDirection: 'reverse'}}></div>
                  </div>

                  {/* Floating Particles */}
                  <div className="absolute top-16 left-40 w-2 h-2 bg-blue-400 rounded-full animate-ping"></div>
                  <div className="absolute bottom-20 left-24 w-1.5 h-1.5 bg-purple-400 rounded-full animate-ping" style={{animationDelay: '1s'}}></div>
                  <div className="absolute top-40 right-32 w-1 h-1 bg-green-400 rounded-full animate-ping" style={{animationDelay: '2s'}}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced BBPS & Recharge Services Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <h2 className="text-4xl font-bold text-gray-900">
                SovaPay's <span className="text-blue-600">BBPS</span> & Recharge Services
              </h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">High Commissions</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Earn attractive commissions on each bill payment and recharge 
                    transaction. The competitive commission structure boosts your 
                    income and offers a stable source of income for your business.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Comprehensive Service Range</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Pay utility bills, mobile recharges, DTH recharges and other services 
                    across the globe. Offer your customers a solution so that they can 
                    come back to you time and again, increasing overall revenue.
                  </p>
                </div>
              </div>
            </div>

            {/* Right Content - Enhanced BBPS Animation */}
            <div className="relative">
              <div className="relative w-full h-96 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-3xl p-8 overflow-hidden">
                {/* Central BBPS Hub */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full shadow-2xl flex items-center justify-center relative">
                    <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-sm">BBPS</span>
                    </div>
                    
                    {/* Orbiting Service Icons */}
                    <div className="absolute inset-0 animate-spin" style={{animationDuration: '10s'}}>
                      <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg">
                        <Zap className="w-4 h-4 text-white" />
                      </div>
                      <div className="absolute -right-8 top-1/2 transform -translate-y-1/2 w-8 h-8 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center shadow-lg">
                        <Smartphone className="w-4 h-4 text-white" />
                      </div>
                      <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center shadow-lg">
                        <Wifi className="w-4 h-4 text-white" />
                      </div>
                      <div className="absolute -left-8 top-1/2 transform -translate-y-1/2 w-8 h-8 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
                        <Globe className="w-4 h-4 text-white" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* People Using Services */}
                <div className="absolute left-8 bottom-16">
                  <div className="relative">
                    <div className="w-16 h-20 bg-gradient-to-b from-blue-500 to-blue-700 rounded-t-full relative animate-float-slow">
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-yellow-200 rounded-full"></div>
                      <div className="absolute top-2 left-1/2 transform -translate-x-1/2">
                        <CreditCard className="w-4 h-4 text-white" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="absolute right-8 top-16">
                  <div className="relative">
                    <div className="w-16 h-20 bg-gradient-to-b from-green-500 to-green-700 rounded-t-full relative animate-float-medium">
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-6 h-6 bg-yellow-200 rounded-full"></div>
                      <div className="absolute top-2 left-1/2 transform -translate-x-1/2">
                        <CheckCircle className="w-4 h-4 text-white animate-pulse" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Features Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Animation */}
            <div className="relative">
              <div className="relative w-full h-96 bg-gradient-to-br from-green-100 to-blue-100 rounded-3xl p-8 overflow-hidden">
                {/* Enhanced Payment Scene */}
                <div className="absolute left-1/4 top-1/2 transform -translate-y-1/2">
                  {/* Bank Building */}
                  <div className="w-16 h-20 bg-gradient-to-b from-indigo-400 to-indigo-600 rounded-t-lg shadow-xl relative">
                    <div className="absolute top-2 left-1/2 transform -translate-x-1/2 text-white text-xs font-bold">BANK</div>
                    <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div>
                  </div>
                </div>

                <div className="absolute right-1/4 top-1/2 transform -translate-y-1/2">
                  {/* Person with Mobile */}
                  <div className="w-12 h-16 bg-gradient-to-b from-orange-400 to-orange-600 rounded-t-full relative">
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-yellow-200 rounded-full"></div>
                    <div className="absolute top-1 right-0 w-3 h-5 bg-gray-800 rounded"></div>
                  </div>
                </div>

                {/* Money Flow */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-32 h-1 bg-gradient-to-r from-green-400 to-blue-500 rounded-full relative">
                    <div className="absolute top-1/2 transform -translate-y-1/2 w-3 h-3 bg-yellow-400 rounded-full animate-money-flow"></div>
                  </div>
                </div>

                {/* Floating Elements */}
                <div className="absolute top-8 left-8 w-6 h-6 bg-green-400 rounded-full animate-bounce flex items-center justify-center">
                  <DollarSign className="w-3 h-3 text-white" />
                </div>
                <div className="absolute bottom-8 right-8 w-4 h-4 bg-blue-400 rounded-full animate-pulse"></div>
              </div>
            </div>

            {/* Right Content */}
            <div className="space-y-8">
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Increased Profitability</h3>
                    <p className="text-gray-600 leading-relaxed">
                      Working with SovaPay means that you receive high commission rates 
                      that will improve your revenues as you provide valuable services to 
                      your community.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Target className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Expand Your Offerings</h3>
                    <p className="text-gray-600 leading-relaxed">
                      Offer these basic services to attract more clients and set your 
                      business as a one-stop shop for all your customers' needs.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Benefits Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-600/80 via-purple-600/80 to-indigo-600/80"></div>
          <div className="absolute top-20 left-20 w-32 h-32 bg-white/10 rounded-full blur-2xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-40 h-40 bg-white/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Enhanced Benefit Cards */}
            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <CheckCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Instant Confirmation</h3>
              <p className="text-gray-600 leading-relaxed">
                Get confirmation for all the bills and recharges on the same page to make the transaction process fast and secure.
              </p>
            </div>

            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Building2 className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">All Bill Payments & Recharges Under One Roof</h3>
              <p className="text-gray-600 leading-relaxed">
                Manage utility bills, mobile recharges, and DTH services in one place with the help of BBPS offered by SovaPay.
              </p>
            </div>

            <div className="group bg-white/95 backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:transform hover:scale-105">
              <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <Star className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Attractive Commission Rates</h3>
              <p className="text-gray-600 leading-relaxed">
                Competitive Commission rates on each recharge and bill payment through SovaPay's BBPS services.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gray-900 via-blue-900 to-indigo-900 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-gray-900/90 via-blue-900/90 to-indigo-900/90"></div>
          <div className="absolute top-20 left-20 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
        </div>

        <div className="container mx-auto px-6 text-center relative z-10">
          <div className="max-w-4xl mx-auto space-y-8">
            <h2 className="text-4xl lg:text-5xl font-bold text-white leading-tight">
              Get started with SovaPay's BBPS and Recharge Services today and start earning with our easy-to-use platform!
            </h2>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg">
                Contact Us
              </button>
              <button className="border-2 border-white/30 hover:border-white/50 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 hover:bg-white/10 backdrop-blur-sm">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      <style jsx>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .preserve-3d {
          transform-style: preserve-3d;
        }
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          33% { transform: translateY(-8px) translateX(4px) rotateZ(2deg); }
          66% { transform: translateY(4px) translateX(-2px) rotateZ(-1deg); }
        }
        @keyframes float-medium {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          50% { transform: translateY(-12px) translateX(6px) rotateZ(3deg); }
        }
        @keyframes float-fast {
          0%, 100% { transform: translateY(0px) translateX(0px) rotateZ(0deg); }
          25% { transform: translateY(-6px) translateX(3px) rotateZ(1deg); }
          75% { transform: translateY(6px) translateX(-3px) rotateZ(-2deg); }
        }
        @keyframes money-flow {
          0% { left: 0; }
          100% { left: calc(100% - 12px); }
        }
        @keyframes coin-bounce {
          0%, 100% { transform: translateY(0px) rotateY(0deg); }
          25% { transform: translateY(-8px) rotateY(90deg); }
          50% { transform: translateY(-4px) rotateY(180deg); }
          75% { transform: translateY(-8px) rotateY(270deg); }
        }
        .animate-float-slow {
          animation: float-slow 6s ease-in-out infinite;
        }
        .animate-float-medium {
          animation: float-medium 4s ease-in-out infinite;
        }
        .animate-float-fast {
          animation: float-fast 3s ease-in-out infinite;
        }
        .animate-money-flow {
          animation: money-flow 3s ease-in-out infinite;
        }
        .animate-coin-bounce {
          animation: coin-bounce 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default UtilityServices;